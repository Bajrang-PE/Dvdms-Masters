# React + Vite
This application is created and managed by CDAC , Noida, this is a Unified Dvdms system for all states.
Developer : BG

{"state":"JH","userId":14848,"username":"cdac_admin","isLogin":"true"}
{"state":"AS","userId":20000001,"username":"admin_dvdms","isLogin":"true"}
