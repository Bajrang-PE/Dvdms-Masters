import { fetchData } from "../../../utils/ApiHook";


export const getHpRcContractTypesCmb = async (hospitalCode, dwhTypeId, status) => {
    try {
        const response = await fetchData(
            `/hp-api/rate-contracts/type-combo?hospitalCode=${hospitalCode}&dwhTypeId=${dwhTypeId}&status=${status}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching items:", error);
        throw error;
    }
};

export const getHpRcSuppliersCmb = async (hospitalCode, contractTypeId, status) => {
    try {
        const response = await fetchData(
            `/hp-api/rate-contracts/supplier-combo?hospitalCode=${hospitalCode}&contractTypeId=${contractTypeId}&status=${status}`
        );
        return response.data?.data;
    } catch (error) {
        console.error("Error fetching items:", error);
        throw error;
    }
};

export const getHpRcDrugNamesCmb = async (hospitalCode, supplierId, contractTypeId, status) => {
    try {
        const response = await fetchData(
            `/hp-api/rate-contracts/item-combo?hospitalCode=${hospitalCode}&supplierId=${supplierId}&contractTypeId=${contractTypeId}&status=${status}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching drugs:", error);
        throw error;
    }
};

export const getHpRcStoreNameCmb = async (hospitalCode) => {
    try {
        const response = await fetchData(
            `/hp-api/stores/10001?hospitalCode=${hospitalCode}`
        );
        return response.data;
    } catch (err) {
        console.error("Error fetching store name : ", err);
        throw err;
    }
};

export const getHpRcStatusCmb = async () => {
    try {
        const response = await fetchData(
            `/hp-api/rate-contracts/rc-status-combo`
        );
        return response.data;
    } catch (err) {
        console.error("Error fetching store name : ", err);
        throw err;
    }
};

export const getHpRcSingleRcDetails = async (hospitalCode, rcId) => {
    try {
        const response = await fetchData(
            `/hp-api/rate-contracts/${rcId}?hospitalCode=${hospitalCode}`
        );
        return response.data;
    } catch (err) {
        console.error("Error fetching store name : ", err);
        throw err;
    }
};

export const getHpRcListData = async (hospitalCode, suppId, itemBrandId, contractTypeId, status, pageNo, size) => {
    try {
        const response = await fetchData(
            `/hp-api/rate-contracts?hospitalCode=${hospitalCode}&supplierId=${suppId}&itemBrandId=${itemBrandId}&contractTypeId=${contractTypeId}&status=${status}&page=${pageNo}&size=${size}`
        );
        return response.data;
    } catch (err) {
        console.error("Error fetching store name : ", err);
        throw err;
    }
};


