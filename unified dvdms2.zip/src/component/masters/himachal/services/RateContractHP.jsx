import React from 'react'

const RateContractHP = () => {
    return (
        <div>
            HP
        </div>
    )
}

export default RateContractHP
