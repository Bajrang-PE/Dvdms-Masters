import {
  require_react
} from "./chunk-32EALFBN.js";
import "./chunk-G3PMV62Z.js";
export default require_react();
