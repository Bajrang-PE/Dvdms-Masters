import {
  require_jsx_runtime
} from "./chunk-EO7JTZSA.js";
import {
  require_react_dom
} from "./chunk-FYGYNQUM.js";
import {
  require_react
} from "./chunk-32EALFBN.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/react-virtuoso/dist/index.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var import_react = __toESM(require_react(), 1);
var import_react_dom = __toESM(require_react_dom(), 1);
var we = 0;
var zt = 1;
var qt = 2;
var kn = 4;
function un(t) {
  return () => t;
}
function fo(t) {
  t();
}
function ne(t, e) {
  return (n) => t(e(n));
}
function an(t, e) {
  return () => t(e);
}
function mo(t, e) {
  return (n) => t(e, n);
}
function We(t) {
  return t !== void 0;
}
function po(...t) {
  return () => {
    t.map(fo);
  };
}
function Yt() {
}
function ve(t, e) {
  return e(t), t;
}
function ho(t, e) {
  return e(t);
}
function X(...t) {
  return t;
}
function K(t, e) {
  return t(zt, e);
}
function G(t, e) {
  t(we, e);
}
function Ge(t) {
  t(qt);
}
function ot(t) {
  return t(kn);
}
function O(t, e) {
  return K(t, mo(e, we));
}
function Tt(t, e) {
  const n = t(zt, (o) => {
    n(), e(o);
  });
  return n;
}
function dn(t) {
  let e, n;
  return (o) => (r) => {
    e = r, n && clearTimeout(n), n = setTimeout(() => {
      o(e);
    }, t);
  };
}
function Fn(t, e) {
  return t === e;
}
function Z(t = Fn) {
  let e;
  return (n) => (o) => {
    t(e, o) || (e = o, n(o));
  };
}
function A(t) {
  return (e) => (n) => {
    t(n) && e(n);
  };
}
function E(t) {
  return (e) => ne(e, t);
}
function Rt(t) {
  return (e) => () => {
    e(t);
  };
}
function x(t, ...e) {
  const n = go(...e);
  return (o, r) => {
    switch (o) {
      case qt:
        Ge(t);
        return;
      case zt:
        return K(t, n(r));
    }
  };
}
function bt(t, e) {
  return (n) => (o) => {
    n(e = t(e, o));
  };
}
function Dt(t) {
  return (e) => (n) => {
    t > 0 ? t-- : e(n);
  };
}
function kt(t) {
  let e = null, n;
  return (o) => (r) => {
    e = r, !n && (n = setTimeout(() => {
      n = void 0, o(e);
    }, t));
  };
}
function N(...t) {
  const e = new Array(t.length);
  let n = 0, o = null;
  const r = Math.pow(2, t.length) - 1;
  return t.forEach((s, i) => {
    const l = Math.pow(2, i);
    K(s, (c) => {
      const a = n;
      n = n | l, e[i] = c, a !== r && n === r && o && (o(), o = null);
    });
  }), (s) => (i) => {
    const l = () => {
      s([i].concat(e));
    };
    n === r ? l() : o = l;
  };
}
function go(...t) {
  return (e) => t.reduceRight(ho, e);
}
function Io(t) {
  let e, n;
  const o = () => e == null ? void 0 : e();
  return function(r, s) {
    switch (r) {
      case zt:
        return s ? n === s ? void 0 : (o(), n = s, e = K(t, s), e) : (o(), Yt);
      case qt:
        o(), n = null;
        return;
    }
  };
}
function C(t) {
  let e = t;
  const n = $();
  return (o, r) => {
    switch (o) {
      case we:
        e = r;
        break;
      case zt: {
        r(e);
        break;
      }
      case kn:
        return e;
    }
    return n(o, r);
  };
}
function ct(t, e) {
  return ve(C(e), (n) => O(t, n));
}
function $() {
  const t = [];
  return (e, n) => {
    switch (e) {
      case we:
        t.slice().forEach((o) => {
          o(n);
        });
        return;
      case qt:
        t.splice(0, t.length);
        return;
      case zt:
        return t.push(n), () => {
          const o = t.indexOf(n);
          o > -1 && t.splice(o, 1);
        };
    }
  };
}
function ht(t) {
  return ve($(), (e) => O(t, e));
}
function U(t, e = [], { singleton: n } = { singleton: true }) {
  return {
    constructor: t,
    dependencies: e,
    id: So(),
    singleton: n
  };
}
var So = () => Symbol();
function xo(t) {
  const e = /* @__PURE__ */ new Map(), n = ({ constructor: o, dependencies: r, id: s, singleton: i }) => {
    if (i && e.has(s))
      return e.get(s);
    const l = o(r.map((c) => n(c)));
    return i && e.set(s, l), l;
  };
  return n(t);
}
function rt(...t) {
  const e = $(), n = new Array(t.length);
  let o = 0;
  const r = Math.pow(2, t.length) - 1;
  return t.forEach((s, i) => {
    const l = Math.pow(2, i);
    K(s, (c) => {
      n[i] = c, o = o | l, o === r && G(e, n);
    });
  }), function(s, i) {
    switch (s) {
      case qt: {
        Ge(e);
        return;
      }
      case zt:
        return o === r && i(n), K(e, i);
    }
  };
}
function V(t, e = Fn) {
  return x(t, Z(e));
}
function Le(...t) {
  return function(e, n) {
    switch (e) {
      case qt:
        return;
      case zt:
        return po(...t.map((o) => K(o, n)));
    }
  };
}
var mt = ((t) => (t[t.DEBUG = 0] = "DEBUG", t[t.INFO = 1] = "INFO", t[t.WARN = 2] = "WARN", t[t.ERROR = 3] = "ERROR", t))(mt || {});
var To = {
  0: "debug",
  3: "error",
  1: "log",
  2: "warn"
};
var Co = () => typeof globalThis > "u" ? window : globalThis;
var Vt = U(
  () => {
    const t = C(
      3
      /* ERROR */
    );
    return {
      log: C((n, o, r = 1) => {
        var i;
        const s = (i = Co().VIRTUOSO_LOG_LEVEL) != null ? i : ot(t);
        r >= s && console[To[r]](
          "%creact-virtuoso: %c%s %o",
          "color: #0253b3; font-weight: bold",
          "color: initial",
          n,
          o
        );
      }),
      logLevel: t
    };
  },
  [],
  { singleton: true }
);
function Ht(t, e, n) {
  return _e(t, e, n).callbackRef;
}
function _e(t, e, n) {
  const o = import_react.default.useRef(null);
  let r = (i) => {
  };
  const s = import_react.default.useMemo(() => typeof ResizeObserver < "u" ? new ResizeObserver((i) => {
    const l = () => {
      const c = i[0].target;
      c.offsetParent !== null && t(c);
    };
    n ? l() : requestAnimationFrame(l);
  }) : null, [t, n]);
  return r = (i) => {
    i && e ? (s == null || s.observe(i), o.current = i) : (o.current && (s == null || s.unobserve(o.current)), o.current = null);
  }, { callbackRef: r, ref: o };
}
function On(t, e, n, o, r, s, i, l, c) {
  const a = import_react.default.useCallback(
    (m) => {
      const S = wo(m.children, e, l ? "offsetWidth" : "offsetHeight", r);
      let g = m.parentElement;
      for (; !g.dataset.virtuosoScroller; )
        g = g.parentElement;
      const I = g.lastElementChild.dataset.viewportType === "window";
      let w;
      I && (w = g.ownerDocument.defaultView);
      const v = i ? l ? i.scrollLeft : i.scrollTop : I ? l ? w.scrollX || w.document.documentElement.scrollLeft : w.scrollY || w.document.documentElement.scrollTop : l ? g.scrollLeft : g.scrollTop, h = i ? l ? i.scrollWidth : i.scrollHeight : I ? l ? w.document.documentElement.scrollWidth : w.document.documentElement.scrollHeight : l ? g.scrollWidth : g.scrollHeight, p = i ? l ? i.offsetWidth : i.offsetHeight : I ? l ? w.innerWidth : w.innerHeight : l ? g.offsetWidth : g.offsetHeight;
      o({
        scrollHeight: h,
        scrollTop: Math.max(v, 0),
        viewportHeight: p
      }), s == null || s(
        l ? fn("column-gap", getComputedStyle(m).columnGap, r) : fn("row-gap", getComputedStyle(m).rowGap, r)
      ), S !== null && t(S);
    },
    [t, e, r, s, i, o, l]
  );
  return _e(a, n, c);
}
function wo(t, e, n, o) {
  const r = t.length;
  if (r === 0)
    return null;
  const s = [];
  for (let i = 0; i < r; i++) {
    const l = t.item(i);
    if (l.dataset.index === void 0)
      continue;
    const c = parseInt(l.dataset.index), a = parseFloat(l.dataset.knownSize), m = e(l, n);
    if (m === 0 && o("Zero-sized element, this should not happen", { child: l }, mt.ERROR), m === a)
      continue;
    const S = s[s.length - 1];
    s.length === 0 || S.size !== m || S.endIndex !== c - 1 ? s.push({ endIndex: c, size: m, startIndex: c }) : s[s.length - 1].endIndex++;
  }
  return s;
}
function fn(t, e, n) {
  return e !== "normal" && !(e != null && e.endsWith("px")) && n(`${t} was not resolved to pixel value correctly`, e, mt.WARN), e === "normal" ? 0 : parseInt(e != null ? e : "0", 10);
}
function Ne(t, e, n) {
  const o = import_react.default.useRef(null), r = import_react.default.useCallback(
    (c) => {
      if (!(c != null && c.offsetParent))
        return;
      const a = c.getBoundingClientRect(), m = a.width;
      let S, g;
      if (e) {
        const I = e.getBoundingClientRect(), w = a.top - I.top;
        g = I.height - Math.max(0, w), S = w + e.scrollTop;
      } else {
        const I = i.current.ownerDocument.defaultView;
        g = I.innerHeight - Math.max(0, a.top), S = a.top + I.scrollY;
      }
      o.current = {
        offsetTop: S,
        visibleHeight: g,
        visibleWidth: m
      }, t(o.current);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [t, e]
  ), { callbackRef: s, ref: i } = _e(r, true, n), l = import_react.default.useCallback(() => {
    r(i.current);
  }, [r, i]);
  return import_react.default.useEffect(() => {
    var c;
    if (e) {
      e.addEventListener("scroll", l);
      const a = new ResizeObserver(() => {
        requestAnimationFrame(l);
      });
      return a.observe(e), () => {
        e.removeEventListener("scroll", l), a.unobserve(e);
      };
    } else {
      const a = (c = i.current) == null ? void 0 : c.ownerDocument.defaultView;
      return a == null || a.addEventListener("scroll", l), a == null || a.addEventListener("resize", l), () => {
        a == null || a.removeEventListener("scroll", l), a == null || a.removeEventListener("resize", l);
      };
    }
  }, [l, e, i]), s;
}
var at = U(
  () => {
    const t = $(), e = $(), n = C(0), o = $(), r = C(0), s = $(), i = $(), l = C(0), c = C(0), a = C(0), m = C(0), S = $(), g = $(), I = C(false), w = C(false), v = C(false);
    return O(
      x(
        t,
        E(({ scrollTop: h }) => h)
      ),
      e
    ), O(
      x(
        t,
        E(({ scrollHeight: h }) => h)
      ),
      i
    ), O(e, r), {
      deviation: n,
      fixedFooterHeight: a,
      fixedHeaderHeight: c,
      footerHeight: m,
      headerHeight: l,
      horizontalDirection: w,
      scrollBy: g,
      // input
      scrollContainerState: t,
      scrollHeight: i,
      scrollingInProgress: I,
      // signals
      scrollTo: S,
      scrollTop: e,
      skipAnimationFrameInResizeObserver: v,
      smoothScrollTargetReached: o,
      // state
      statefulScrollTop: r,
      viewportHeight: s
    };
  },
  [],
  { singleton: true }
);
var oe = { lvl: 0 };
function Ln(t, e) {
  const n = t.length;
  if (n === 0)
    return [];
  let { index: o, value: r } = e(t[0]);
  const s = [];
  for (let i = 1; i < n; i++) {
    const { index: l, value: c } = e(t[i]);
    s.push({ end: l - 1, start: o, value: r }), o = l, r = c;
  }
  return s.push({ end: 1 / 0, start: o, value: r }), s;
}
function j(t) {
  return t === oe;
}
function re(t, e) {
  if (!j(t))
    return e === t.k ? t.v : e < t.k ? re(t.l, e) : re(t.r, e);
}
function wt(t, e, n = "k") {
  if (j(t))
    return [-1 / 0, void 0];
  if (Number(t[n]) === e)
    return [t.k, t.v];
  if (Number(t[n]) < e) {
    const o = wt(t.r, e, n);
    return o[0] === -1 / 0 ? [t.k, t.v] : o;
  }
  return wt(t.l, e, n);
}
function pt(t, e, n) {
  return j(t) ? Pn(e, n, 1) : e === t.k ? st(t, { k: e, v: n }) : e < t.k ? mn(st(t, { l: pt(t.l, e, n) })) : mn(st(t, { r: pt(t.r, e, n) }));
}
function jt() {
  return oe;
}
function ye(t, e, n) {
  if (j(t))
    return [];
  const o = wt(t, e)[0];
  return vo(Ve(t, o, n));
}
function ze(t, e) {
  if (j(t)) return oe;
  const { k: n, l: o, r } = t;
  if (e === n) {
    if (j(o))
      return r;
    if (j(r))
      return o;
    {
      const [s, i] = Vn(o);
      return ge(st(t, { k: s, l: zn(o), v: i }));
    }
  } else return e < n ? ge(st(t, { l: ze(o, e) })) : ge(st(t, { r: ze(r, e) }));
}
function Gt(t) {
  return j(t) ? [] : [...Gt(t.l), { k: t.k, v: t.v }, ...Gt(t.r)];
}
function Ve(t, e, n) {
  if (j(t))
    return [];
  const { k: o, l: r, r: s, v: i } = t;
  let l = [];
  return o > e && (l = l.concat(Ve(r, e, n))), o >= e && o <= n && l.push({ k: o, v: i }), o <= n && (l = l.concat(Ve(s, e, n))), l;
}
function ge(t) {
  const { l: e, lvl: n, r: o } = t;
  if (o.lvl >= n - 1 && e.lvl >= n - 1)
    return t;
  if (n > o.lvl + 1) {
    if (Ee(e))
      return An(st(t, { lvl: n - 1 }));
    if (!j(e) && !j(e.r))
      return st(e.r, {
        l: st(e, { r: e.r.l }),
        lvl: n,
        r: st(t, {
          l: e.r.r,
          lvl: n - 1
        })
      });
    throw new Error("Unexpected empty nodes");
  } else {
    if (Ee(t))
      return Pe(st(t, { lvl: n - 1 }));
    if (!j(o) && !j(o.l)) {
      const r = o.l, s = Ee(r) ? o.lvl - 1 : o.lvl;
      return st(r, {
        l: st(t, {
          lvl: n - 1,
          r: r.l
        }),
        lvl: r.lvl + 1,
        r: Pe(st(o, { l: r.r, lvl: s }))
      });
    } else
      throw new Error("Unexpected empty nodes");
  }
}
function st(t, e) {
  return Pn(
    e.k !== void 0 ? e.k : t.k,
    e.v !== void 0 ? e.v : t.v,
    e.lvl !== void 0 ? e.lvl : t.lvl,
    e.l !== void 0 ? e.l : t.l,
    e.r !== void 0 ? e.r : t.r
  );
}
function zn(t) {
  return j(t.r) ? t.l : ge(st(t, { r: zn(t.r) }));
}
function Ee(t) {
  return j(t) || t.lvl > t.r.lvl;
}
function Vn(t) {
  return j(t.r) ? [t.k, t.v] : Vn(t.r);
}
function Pn(t, e, n, o = oe, r = oe) {
  return { k: t, l: o, lvl: n, r, v: e };
}
function mn(t) {
  return Pe(An(t));
}
function An(t) {
  const { l: e } = t;
  return !j(e) && e.lvl === t.lvl ? st(e, { r: st(t, { l: e.r }) }) : t;
}
function Pe(t) {
  const { lvl: e, r: n } = t;
  return !j(n) && !j(n.r) && n.lvl === e && n.r.lvl === e ? st(n, { l: st(t, { r: n.l }), lvl: e + 1 }) : t;
}
function vo(t) {
  return Ln(t, ({ k: e, v: n }) => ({ index: e, value: n }));
}
function Mn(t, e) {
  return !!(t && t.startIndex === e.startIndex && t.endIndex === e.endIndex);
}
function se(t, e) {
  return !!(t && t[0] === e[0] && t[1] === e[1]);
}
var De = U(
  () => ({ recalcInProgress: C(false) }),
  [],
  { singleton: true }
);
function Wn(t, e, n) {
  return t[Se(t, e, n)];
}
function Se(t, e, n, o = 0) {
  let r = t.length - 1;
  for (; o <= r; ) {
    const s = Math.floor((o + r) / 2), i = t[s], l = n(i, e);
    if (l === 0)
      return s;
    if (l === -1) {
      if (r - o < 2)
        return s - 1;
      r = s - 1;
    } else {
      if (r === o)
        return s;
      o = s + 1;
    }
  }
  throw new Error(`Failed binary finding record in array - ${t.join(",")}, searched for ${e}`);
}
function yo(t, e, n, o) {
  const r = Se(t, e, o), s = Se(t, n, o, r);
  return t.slice(r, s + 1);
}
function vt(t, e) {
  return Math.round(t.getBoundingClientRect()[e]);
}
function Re(t) {
  return !j(t.groupOffsetTree);
}
function $e({ index: t }, e) {
  return e === t ? 0 : e < t ? -1 : 1;
}
function Ro() {
  return {
    groupIndices: [],
    groupOffsetTree: jt(),
    lastIndex: 0,
    lastOffset: 0,
    lastSize: 0,
    offsetTree: [],
    sizeTree: jt()
  };
}
function bo(t, e) {
  let n = j(t) ? 0 : 1 / 0;
  for (const o of e) {
    const { endIndex: r, size: s, startIndex: i } = o;
    if (n = Math.min(n, i), j(t)) {
      t = pt(t, 0, s);
      continue;
    }
    const l = ye(t, i - 1, r + 1);
    if (l.some(Lo(o)))
      continue;
    let c = false, a = false;
    for (const { end: m, start: S, value: g } of l)
      c ? (r >= S || s === g) && (t = ze(t, S)) : (a = g !== s, c = true), m > r && r >= S && g !== s && (t = pt(t, r + 1, g));
    a && (t = pt(t, i, s));
  }
  return [t, n];
}
function Ho(t) {
  return typeof t.groupIndex < "u";
}
function Eo({ offset: t }, e) {
  return e === t ? 0 : e < t ? -1 : 1;
}
function ie(t, e, n) {
  if (e.length === 0)
    return 0;
  const { index: o, offset: r, size: s } = Wn(e, t, $e), i = t - o, l = s * i + (i - 1) * n + r;
  return l > 0 ? l + n : l;
}
function Gn(t, e) {
  if (!Re(e))
    return t;
  let n = 0;
  for (; e.groupIndices[n] <= t + n; )
    n++;
  return t + n;
}
function _n(t, e, n) {
  if (Ho(t))
    return e.groupIndices[t.groupIndex] + 1;
  {
    const o = t.index === "LAST" ? n : t.index;
    let r = Gn(o, e);
    return r = Math.max(0, r, Math.min(n, r)), r;
  }
}
function Bo(t, e, n, o = 0) {
  return o > 0 && (e = Math.max(e, Wn(t, o, $e).offset)), Ln(yo(t, e, n, Eo), Oo);
}
function ko(t, [e, n, o, r]) {
  e.length > 0 && o("received item sizes", e, mt.DEBUG);
  const s = t.sizeTree;
  let i = s, l = 0;
  if (n.length > 0 && j(s) && e.length === 2) {
    const g = e[0].size, I = e[1].size;
    i = n.reduce((w, v) => pt(pt(w, v, g), v + 1, I), i);
  } else
    [i, l] = bo(i, e);
  if (i === s)
    return t;
  const { lastIndex: c, lastOffset: a, lastSize: m, offsetTree: S } = Ae(t.offsetTree, l, i, r);
  return {
    groupIndices: n,
    groupOffsetTree: n.reduce((g, I) => pt(g, I, ie(I, S, r)), jt()),
    lastIndex: c,
    lastOffset: a,
    lastSize: m,
    offsetTree: S,
    sizeTree: i
  };
}
function Fo(t) {
  return Gt(t).map(({ k: e, v: n }, o, r) => {
    const s = r[o + 1];
    return { endIndex: s ? s.k - 1 : 1 / 0, size: n, startIndex: e };
  });
}
function pn(t, e) {
  let n = 0, o = 0;
  for (; n < t; )
    n += e[o + 1] - e[o] - 1, o++;
  return o - (n === t ? 0 : 1);
}
function Ae(t, e, n, o) {
  let r = t, s = 0, i = 0, l = 0, c = 0;
  if (e !== 0) {
    c = Se(r, e - 1, $e), l = r[c].offset;
    const m = wt(n, e - 1);
    s = m[0], i = m[1], r.length && r[c].size === wt(n, e)[1] && (c -= 1), r = r.slice(0, c + 1);
  } else
    r = [];
  for (const { start: a, value: m } of ye(n, e, 1 / 0)) {
    const S = a - s, g = S * i + l + S * o;
    r.push({
      index: a,
      offset: g,
      size: m
    }), s = a, l = g, i = m;
  }
  return {
    lastIndex: s,
    lastOffset: l,
    lastSize: i,
    offsetTree: r
  };
}
function Oo(t) {
  return { index: t.index, value: t };
}
function Lo(t) {
  const { endIndex: e, size: n, startIndex: o } = t;
  return (r) => r.start === o && (r.end === e || r.end === 1 / 0) && r.value === n;
}
var zo = {
  offsetHeight: "height",
  offsetWidth: "width"
};
var Et = U(
  ([{ log: t }, { recalcInProgress: e }]) => {
    const n = $(), o = $(), r = ct(o, 0), s = $(), i = $(), l = C(0), c = C([]), a = C(void 0), m = C(void 0), S = C((f, d) => vt(f, zo[d])), g = C(void 0), I = C(0), w = Ro(), v = ct(
      x(n, N(c, t, I), bt(ko, w), Z()),
      w
    ), h = ct(
      x(
        c,
        Z(),
        bt((f, d) => ({ current: d, prev: f.current }), {
          current: [],
          prev: []
        }),
        E(({ prev: f }) => f)
      ),
      []
    );
    O(
      x(
        c,
        A((f) => f.length > 0),
        N(v, I),
        E(([f, d, y]) => {
          const B = f.reduce((k, L, z) => pt(k, L, ie(L, d.offsetTree, y) || z), jt());
          return {
            ...d,
            groupIndices: f,
            groupOffsetTree: B
          };
        })
      ),
      v
    ), O(
      x(
        o,
        N(v),
        A(([f, { lastIndex: d }]) => f < d),
        E(([f, { lastIndex: d, lastSize: y }]) => [
          {
            endIndex: d,
            size: y,
            startIndex: f
          }
        ])
      ),
      n
    ), O(a, m);
    const p = ct(
      x(
        a,
        E((f) => f === void 0)
      ),
      true
    );
    O(
      x(
        m,
        A((f) => f !== void 0 && j(ot(v).sizeTree)),
        E((f) => [{ endIndex: 0, size: f, startIndex: 0 }])
      ),
      n
    );
    const u = ht(
      x(
        n,
        N(v),
        bt(
          ({ sizes: f }, [d, y]) => ({
            changed: y !== f,
            sizes: y
          }),
          { changed: false, sizes: w }
        ),
        E((f) => f.changed)
      )
    );
    K(
      x(
        l,
        bt(
          (f, d) => ({ diff: f.prev - d, prev: d }),
          { diff: 0, prev: 0 }
        ),
        E((f) => f.diff)
      ),
      (f) => {
        const { groupIndices: d } = ot(v);
        if (f > 0)
          G(e, true), G(s, f + pn(f, d));
        else if (f < 0) {
          const y = ot(h);
          y.length > 0 && (f -= pn(-f, y)), G(i, f);
        }
      }
    ), K(x(l, N(t)), ([f, d]) => {
      f < 0 && d(
        "`firstItemIndex` prop should not be set to less than zero. If you don't know the total count, just use a very high value",
        { firstItemIndex: l },
        mt.ERROR
      );
    });
    const T = ht(s);
    O(
      x(
        s,
        N(v),
        E(([f, d]) => {
          const y = d.groupIndices.length > 0, B = [], k = d.lastSize;
          if (y) {
            const L = re(d.sizeTree, 0);
            let z = 0, _ = 0;
            for (; z < f; ) {
              const F = d.groupIndices[_], Y = d.groupIndices.length === _ + 1 ? 1 / 0 : d.groupIndices[_ + 1] - F - 1;
              B.push({
                endIndex: F,
                size: L,
                startIndex: F
              }), B.push({
                endIndex: F + 1 + Y - 1,
                size: k,
                startIndex: F + 1
              }), _++, z += Y + 1;
            }
            const J = Gt(d.sizeTree);
            return z !== f && J.shift(), J.reduce(
              (F, { k: Y, v: it }) => {
                let dt = F.ranges;
                return F.prevSize !== 0 && (dt = [
                  ...F.ranges,
                  {
                    endIndex: Y + f - 1,
                    size: F.prevSize,
                    startIndex: F.prevIndex
                  }
                ]), {
                  prevIndex: Y + f,
                  prevSize: it,
                  ranges: dt
                };
              },
              {
                prevIndex: f,
                prevSize: 0,
                ranges: B
              }
            ).ranges;
          }
          return Gt(d.sizeTree).reduce(
            (L, { k: z, v: _ }) => ({
              prevIndex: z + f,
              prevSize: _,
              ranges: [...L.ranges, { endIndex: z + f - 1, size: L.prevSize, startIndex: L.prevIndex }]
            }),
            {
              prevIndex: 0,
              prevSize: k,
              ranges: []
            }
          ).ranges;
        })
      ),
      n
    );
    const b = ht(
      x(
        i,
        N(v, I),
        E(([f, { offsetTree: d }, y]) => {
          const B = -f;
          return ie(B, d, y);
        })
      )
    );
    return O(
      x(
        i,
        N(v, I),
        E(([f, d, y]) => {
          if (d.groupIndices.length > 0) {
            if (j(d.sizeTree))
              return d;
            let k = jt();
            const L = ot(h);
            let z = 0, _ = 0, J = 0;
            for (; z < -f; ) {
              J = L[_];
              const F = L[_ + 1] - J - 1;
              _++, z += F + 1;
            }
            if (k = Gt(d.sizeTree).reduce((F, { k: Y, v: it }) => pt(F, Math.max(0, Y + f), it), k), z !== -f) {
              const F = re(d.sizeTree, J);
              k = pt(k, 0, F);
              const Y = wt(d.sizeTree, -f + 1)[1];
              k = pt(k, 1, Y);
            }
            return {
              ...d,
              sizeTree: k,
              ...Ae(d.offsetTree, 0, k, y)
            };
          } else {
            const k = Gt(d.sizeTree).reduce((L, { k: z, v: _ }) => pt(L, Math.max(0, z + f), _), jt());
            return {
              ...d,
              sizeTree: k,
              ...Ae(d.offsetTree, 0, k, y)
            };
          }
        })
      ),
      v
    ), {
      beforeUnshiftWith: T,
      // input
      data: g,
      defaultItemSize: m,
      firstItemIndex: l,
      fixedItemSize: a,
      gap: I,
      groupIndices: c,
      itemSize: S,
      listRefresh: u,
      shiftWith: i,
      shiftWithOffset: b,
      sizeRanges: n,
      // output
      sizes: v,
      statefulTotalCount: r,
      totalCount: o,
      trackItemSizes: p,
      unshiftWith: s
    };
  },
  X(Vt, De),
  { singleton: true }
);
function Vo(t) {
  return t.reduce(
    (e, n) => (e.groupIndices.push(e.totalCount), e.totalCount += n + 1, e),
    {
      groupIndices: [],
      totalCount: 0
    }
  );
}
var Nn = U(
  ([{ groupIndices: t, sizes: e, totalCount: n }, { headerHeight: o, scrollTop: r }]) => {
    const s = $(), i = $(), l = ht(x(s, E(Vo)));
    return O(
      x(
        l,
        E((c) => c.totalCount)
      ),
      n
    ), O(
      x(
        l,
        E((c) => c.groupIndices)
      ),
      t
    ), O(
      x(
        rt(r, e, o),
        A(([c, a]) => Re(a)),
        E(([c, a, m]) => wt(a.groupOffsetTree, Math.max(c - m, 0), "v")[0]),
        Z(),
        E((c) => [c])
      ),
      i
    ), { groupCounts: s, topItemsIndexes: i };
  },
  X(Et, at)
);
var Pt = U(
  ([{ log: t }]) => {
    const e = C(false), n = ht(
      x(
        e,
        A((o) => o),
        Z()
      )
    );
    return K(e, (o) => {
      o && ot(t)("props updated", {}, mt.DEBUG);
    }), { didMount: n, propsReady: e };
  },
  X(Vt),
  { singleton: true }
);
var Po = typeof document < "u" && "scrollBehavior" in document.documentElement.style;
function Dn(t) {
  const e = typeof t == "number" ? { index: t } : t;
  return e.align || (e.align = "start"), (!e.behavior || !Po) && (e.behavior = "auto"), e.offset || (e.offset = 0), e;
}
var ce = U(
  ([
    { gap: t, listRefresh: e, sizes: n, totalCount: o },
    {
      fixedFooterHeight: r,
      fixedHeaderHeight: s,
      footerHeight: i,
      headerHeight: l,
      scrollingInProgress: c,
      scrollTo: a,
      smoothScrollTargetReached: m,
      viewportHeight: S
    },
    { log: g }
  ]) => {
    const I = $(), w = $(), v = C(0);
    let h = null, p = null, u = null;
    function T() {
      h && (h(), h = null), u && (u(), u = null), p && (clearTimeout(p), p = null), G(c, false);
    }
    return O(
      x(
        I,
        N(n, S, o, v, l, i, g),
        N(t, s, r),
        E(
          ([
            [b, f, d, y, B, k, L, z],
            _,
            J,
            nt
          ]) => {
            const F = Dn(b), { align: Y, behavior: it, offset: dt } = F, St = y - 1, ft = _n(F, f, St);
            let ut = ie(ft, f.offsetTree, _) + k;
            Y === "end" ? (ut += J + wt(f.sizeTree, ft)[1] - d + nt, ft === St && (ut += L)) : Y === "center" ? ut += (J + wt(f.sizeTree, ft)[1] - d + nt) / 2 : ut -= B, dt && (ut += dt);
            const At = (xt) => {
              T(), xt ? (z("retrying to scroll to", { location: b }, mt.DEBUG), G(I, b)) : (G(w, true), z("list did not change, scroll successful", {}, mt.DEBUG));
            };
            if (T(), it === "smooth") {
              let xt = false;
              u = K(e, (Xt) => {
                xt = xt || Xt;
              }), h = Tt(m, () => {
                At(xt);
              });
            } else
              h = Tt(x(e, Ao(150)), At);
            return p = setTimeout(() => {
              T();
            }, 1200), G(c, true), z("scrolling from index to", { behavior: it, index: ft, top: ut }, mt.DEBUG), { behavior: it, top: ut };
          }
        )
      ),
      a
    ), {
      scrollTargetReached: w,
      scrollToIndex: I,
      topListHeight: v
    };
  },
  X(Et, at, Vt),
  { singleton: true }
);
function Ao(t) {
  return (e) => {
    const n = setTimeout(() => {
      e(false);
    }, t);
    return (o) => {
      o && (e(true), clearTimeout(n));
    };
  };
}
function Ue(t, e) {
  t == 0 ? e() : requestAnimationFrame(() => {
    Ue(t - 1, e);
  });
}
function Ke(t, e) {
  const n = e - 1;
  return typeof t == "number" ? t : t.index === "LAST" ? n : t.index;
}
var ue = U(
  ([{ defaultItemSize: t, listRefresh: e, sizes: n }, { scrollTop: o }, { scrollTargetReached: r, scrollToIndex: s }, { didMount: i }]) => {
    const l = C(true), c = C(0), a = C(true);
    return O(
      x(
        i,
        N(c),
        A(([m, S]) => !!S),
        Rt(false)
      ),
      l
    ), O(
      x(
        i,
        N(c),
        A(([m, S]) => !!S),
        Rt(false)
      ),
      a
    ), K(
      x(
        rt(e, i),
        N(l, n, t, a),
        A(([[, m], S, { sizeTree: g }, I, w]) => m && (!j(g) || We(I)) && !S && !w),
        N(c)
      ),
      ([, m]) => {
        Tt(r, () => {
          G(a, true);
        }), Ue(4, () => {
          Tt(o, () => {
            G(l, true);
          }), G(s, m);
        });
      }
    ), {
      initialItemFinalLocationReached: a,
      initialTopMostItemIndex: c,
      scrolledToInitialItem: l
    };
  },
  X(Et, at, ce, Pt),
  { singleton: true }
);
function $n(t, e) {
  return Math.abs(t - e) < 1.01;
}
var le = "up";
var te = "down";
var Mo = "none";
var Wo = {
  atBottom: false,
  notAtBottomBecause: "NOT_SHOWING_LAST_ITEM",
  state: {
    offsetBottom: 0,
    scrollHeight: 0,
    scrollTop: 0,
    viewportHeight: 0
  }
};
var Go = 0;
var ae = U(([{ footerHeight: t, headerHeight: e, scrollBy: n, scrollContainerState: o, scrollTop: r, viewportHeight: s }]) => {
  const i = C(false), l = C(true), c = $(), a = $(), m = C(4), S = C(Go), g = ct(
    x(
      Le(x(V(r), Dt(1), Rt(true)), x(V(r), Dt(1), Rt(false), dn(100))),
      Z()
    ),
    false
  ), I = ct(
    x(Le(x(n, Rt(true)), x(n, Rt(false), dn(200))), Z()),
    false
  );
  O(
    x(
      rt(V(r), V(S)),
      E(([u, T]) => u <= T),
      Z()
    ),
    l
  ), O(x(l, kt(50)), a);
  const w = ht(
    x(
      rt(o, V(s), V(e), V(t), V(m)),
      bt((u, [{ scrollHeight: T, scrollTop: b }, f, d, y, B]) => {
        const k = b + f - T > -B, L = {
          scrollHeight: T,
          scrollTop: b,
          viewportHeight: f
        };
        if (k) {
          let _, J;
          return b > u.state.scrollTop ? (_ = "SCROLLED_DOWN", J = u.state.scrollTop - b) : (_ = "SIZE_DECREASED", J = u.state.scrollTop - b || u.scrollTopDelta), {
            atBottom: true,
            atBottomBecause: _,
            scrollTopDelta: J,
            state: L
          };
        }
        let z;
        return L.scrollHeight > u.state.scrollHeight ? z = "SIZE_INCREASED" : f < u.state.viewportHeight ? z = "VIEWPORT_HEIGHT_DECREASING" : b < u.state.scrollTop ? z = "SCROLLING_UPWARDS" : z = "NOT_FULLY_SCROLLED_TO_LAST_ITEM_BOTTOM", {
          atBottom: false,
          notAtBottomBecause: z,
          state: L
        };
      }, Wo),
      Z((u, T) => u && u.atBottom === T.atBottom)
    )
  ), v = ct(
    x(
      o,
      bt(
        (u, { scrollHeight: T, scrollTop: b, viewportHeight: f }) => {
          if ($n(u.scrollHeight, T))
            return {
              changed: false,
              jump: 0,
              scrollHeight: T,
              scrollTop: b
            };
          {
            const d = T - (b + f) < 1;
            return u.scrollTop !== b && d ? {
              changed: true,
              jump: u.scrollTop - b,
              scrollHeight: T,
              scrollTop: b
            } : {
              changed: true,
              jump: 0,
              scrollHeight: T,
              scrollTop: b
            };
          }
        },
        { changed: false, jump: 0, scrollHeight: 0, scrollTop: 0 }
      ),
      A((u) => u.changed),
      E((u) => u.jump)
    ),
    0
  );
  O(
    x(
      w,
      E((u) => u.atBottom)
    ),
    i
  ), O(x(i, kt(50)), c);
  const h = C(te);
  O(
    x(
      o,
      E(({ scrollTop: u }) => u),
      Z(),
      bt(
        (u, T) => ot(I) ? { direction: u.direction, prevScrollTop: T } : { direction: T < u.prevScrollTop ? le : te, prevScrollTop: T },
        { direction: te, prevScrollTop: 0 }
      ),
      E((u) => u.direction)
    ),
    h
  ), O(x(o, kt(50), Rt(Mo)), h);
  const p = C(0);
  return O(
    x(
      g,
      A((u) => !u),
      Rt(0)
    ),
    p
  ), O(
    x(
      r,
      kt(100),
      N(g),
      A(([u, T]) => !!T),
      bt(([u, T], [b]) => [T, b], [0, 0]),
      E(([u, T]) => T - u)
    ),
    p
  ), {
    atBottomState: w,
    atBottomStateChange: c,
    atBottomThreshold: m,
    atTopStateChange: a,
    atTopThreshold: S,
    isAtBottom: i,
    isAtTop: l,
    isScrolling: g,
    lastJumpDueToItemResize: v,
    scrollDirection: h,
    scrollVelocity: p
  };
}, X(at));
var xe = "top";
var Te = "bottom";
var hn = "none";
function gn(t, e, n) {
  return typeof t == "number" ? n === le && e === xe || n === te && e === Te ? t : 0 : n === le ? e === xe ? t.main : t.reverse : e === Te ? t.main : t.reverse;
}
function In(t, e) {
  var n;
  return typeof t == "number" ? t : (n = t[e]) != null ? n : 0;
}
var je = U(
  ([{ deviation: t, fixedHeaderHeight: e, headerHeight: n, scrollTop: o, viewportHeight: r }]) => {
    const s = $(), i = C(0), l = C(0), c = C(0), a = ct(
      x(
        rt(
          V(o),
          V(r),
          V(n),
          V(s, se),
          V(c),
          V(i),
          V(e),
          V(t),
          V(l)
        ),
        E(
          ([
            m,
            S,
            g,
            [I, w],
            v,
            h,
            p,
            u,
            T
          ]) => {
            const b = m - u, f = h + p, d = Math.max(g - b, 0);
            let y = hn;
            const B = In(T, xe), k = In(T, Te);
            return I -= u, I += g + p, w += g + p, w -= u, I > m + f - B && (y = le), w < m - d + S + k && (y = te), y !== hn ? [
              Math.max(b - g - gn(v, xe, y) - B, 0),
              b - d - p + S + gn(v, Te, y) + k
            ] : null;
          }
        ),
        A((m) => m != null),
        Z(se)
      ),
      [0, 0]
    );
    return {
      increaseViewportBy: l,
      // input
      listBoundary: s,
      overscan: c,
      topListHeight: i,
      // output
      visibleRange: a
    };
  },
  X(at),
  { singleton: true }
);
function _o(t, e, n) {
  if (Re(e)) {
    const o = Gn(t, e);
    return [
      { index: wt(e.groupOffsetTree, o)[0], offset: 0, size: 0 },
      { data: n == null ? void 0 : n[0], index: o, offset: 0, size: 0 }
    ];
  }
  return [{ data: n == null ? void 0 : n[0], index: t, offset: 0, size: 0 }];
}
var Be = {
  bottom: 0,
  firstItemIndex: 0,
  items: [],
  offsetBottom: 0,
  offsetTop: 0,
  top: 0,
  topItems: [],
  topListHeight: 0,
  totalCount: 0
};
function Ie(t, e, n, o, r, s) {
  const { lastIndex: i, lastOffset: l, lastSize: c } = r;
  let a = 0, m = 0;
  if (t.length > 0) {
    a = t[0].offset;
    const v = t[t.length - 1];
    m = v.offset + v.size;
  }
  const S = n - i, g = l + S * c + (S - 1) * o, I = a, w = g - m;
  return {
    bottom: m,
    firstItemIndex: s,
    items: Sn(t, r, s),
    offsetBottom: w,
    offsetTop: a,
    top: I,
    topItems: Sn(e, r, s),
    topListHeight: e.reduce((v, h) => h.size + v, 0),
    totalCount: n
  };
}
function Un(t, e, n, o, r, s) {
  let i = 0;
  if (n.groupIndices.length > 0)
    for (const m of n.groupIndices) {
      if (m - i >= t)
        break;
      i++;
    }
  const l = t + i, c = Ke(e, l), a = Array.from({ length: l }).map((m, S) => ({
    data: s[S + c],
    index: S + c,
    offset: 0,
    size: 0
  }));
  return Ie(a, [], l, r, n, o);
}
function Sn(t, e, n) {
  if (t.length === 0)
    return [];
  if (!Re(e))
    return t.map((a) => ({ ...a, index: a.index + n, originalIndex: a.index }));
  const o = t[0].index, r = t[t.length - 1].index, s = [], i = ye(e.groupOffsetTree, o, r);
  let l, c = 0;
  for (const a of t) {
    (!l || l.end < a.index) && (l = i.shift(), c = e.groupIndices.indexOf(l.start));
    let m;
    a.index === l.start ? m = {
      index: c,
      type: "group"
    } : m = {
      groupIndex: c,
      index: a.index - (c + 1) + n
    }, s.push({
      ...m,
      data: a.data,
      offset: a.offset,
      originalIndex: a.index,
      size: a.size
    });
  }
  return s;
}
var $t = U(
  ([
    { data: t, firstItemIndex: e, gap: n, sizes: o, totalCount: r },
    s,
    { listBoundary: i, topListHeight: l, visibleRange: c },
    { initialTopMostItemIndex: a, scrolledToInitialItem: m },
    { topListHeight: S },
    g,
    { didMount: I },
    { recalcInProgress: w }
  ]) => {
    const v = C([]), h = C(0), p = $();
    O(s.topItemsIndexes, v);
    const u = ct(
      x(
        rt(
          I,
          w,
          V(c, se),
          V(r),
          V(o),
          V(a),
          m,
          V(v),
          V(e),
          V(n),
          t
        ),
        A(([d, y, , B, , , , , , , k]) => {
          const L = k && k.length !== B;
          return d && !y && !L;
        }),
        E(
          ([
            ,
            ,
            [d, y],
            B,
            k,
            L,
            z,
            _,
            J,
            nt,
            F
          ]) => {
            const Y = k, { offsetTree: it, sizeTree: dt } = Y, St = ot(h);
            if (B === 0)
              return { ...Be, totalCount: B };
            if (d === 0 && y === 0)
              return St === 0 ? { ...Be, totalCount: B } : Un(St, L, k, J, nt, F || []);
            if (j(dt))
              return St > 0 ? null : Ie(
                _o(Ke(L, B), Y, F),
                [],
                B,
                nt,
                Y,
                J
              );
            const ft = [];
            if (_.length > 0) {
              const Mt = _[0], yt = _[_.length - 1];
              let Bt = 0;
              for (const R of ye(dt, Mt, yt)) {
                const D = R.value, Q = Math.max(R.start, Mt), lt = Math.min(R.end, yt);
                for (let tt = Q; tt <= lt; tt++)
                  ft.push({ data: F == null ? void 0 : F[tt], index: tt, offset: Bt, size: D }), Bt += D;
              }
            }
            if (!z)
              return Ie([], ft, B, nt, Y, J);
            const ut = _.length > 0 ? _[_.length - 1] + 1 : 0, At = Bo(it, d, y, ut);
            if (At.length === 0)
              return null;
            const xt = B - 1, Xt = ve([], (Mt) => {
              for (const yt of At) {
                const Bt = yt.value;
                let R = Bt.offset, D = yt.start;
                const Q = Bt.size;
                if (Bt.offset < d) {
                  D += Math.floor((d - Bt.offset + nt) / (Q + nt));
                  const tt = D - yt.start;
                  R += tt * Q + tt * nt;
                }
                D < ut && (R += (ut - D) * Q, D = ut);
                const lt = Math.min(yt.end, xt);
                for (let tt = D; tt <= lt && !(R >= y); tt++)
                  Mt.push({ data: F == null ? void 0 : F[tt], index: tt, offset: R, size: Q }), R += Q + nt;
              }
            });
            return Ie(Xt, ft, B, nt, Y, J);
          }
        ),
        //@ts-expect-error filter needs to be fixed
        A((d) => d !== null),
        Z()
      ),
      Be
    );
    O(
      x(
        t,
        A(We),
        E((d) => d == null ? void 0 : d.length)
      ),
      r
    ), O(
      x(
        u,
        E((d) => d.topListHeight)
      ),
      S
    ), O(S, l), O(
      x(
        u,
        E((d) => [d.top, d.bottom])
      ),
      i
    ), O(
      x(
        u,
        E((d) => d.items)
      ),
      p
    );
    const T = ht(
      x(
        u,
        A(({ items: d }) => d.length > 0),
        N(r, t),
        A(([{ items: d }, y]) => d[d.length - 1].originalIndex === y - 1),
        E(([, d, y]) => [d - 1, y]),
        Z(se),
        E(([d]) => d)
      )
    ), b = ht(
      x(
        u,
        kt(200),
        A(({ items: d, topItems: y }) => d.length > 0 && d[0].originalIndex === y.length),
        E(({ items: d }) => d[0].index),
        Z()
      )
    ), f = ht(
      x(
        u,
        A(({ items: d }) => d.length > 0),
        E(({ items: d }) => {
          let y = 0, B = d.length - 1;
          for (; d[y].type === "group" && y < B; )
            y++;
          for (; d[B].type === "group" && B > y; )
            B--;
          return {
            endIndex: d[B].index,
            startIndex: d[y].index
          };
        }),
        Z(Mn)
      )
    );
    return { endReached: T, initialItemCount: h, itemsRendered: p, listState: u, rangeChanged: f, startReached: b, topItemsIndexes: v, ...g };
  },
  X(
    Et,
    Nn,
    je,
    ue,
    ce,
    ae,
    Pt,
    De
  ),
  { singleton: true }
);
var Kn = U(
  ([{ fixedFooterHeight: t, fixedHeaderHeight: e, footerHeight: n, headerHeight: o }, { listState: r }]) => {
    const s = $(), i = ct(
      x(
        rt(n, t, o, e, r),
        E(([l, c, a, m, S]) => l + c + a + m + S.offsetBottom + S.bottom)
      ),
      0
    );
    return O(V(i), s), { totalListHeight: i, totalListHeightChanged: s };
  },
  X(at, $t),
  { singleton: true }
);
var No = U(
  ([{ viewportHeight: t }, { totalListHeight: e }]) => {
    const n = C(false), o = ct(
      x(
        rt(n, t, e),
        A(([r]) => r),
        E(([, r, s]) => Math.max(0, r - s)),
        kt(0),
        Z()
      ),
      0
    );
    return { alignToBottom: n, paddingTopAddition: o };
  },
  X(at, Kn),
  { singleton: true }
);
var jn = U(() => ({
  context: C(null)
}));
var Do = ({
  itemBottom: t,
  itemTop: e,
  locationParams: { align: n, behavior: o, ...r },
  viewportBottom: s,
  viewportTop: i
}) => e < i ? { ...r, align: n != null ? n : "start", behavior: o } : t > s ? { ...r, align: n != null ? n : "end", behavior: o } : null;
var qn = U(
  ([
    { gap: t, sizes: e, totalCount: n },
    { fixedFooterHeight: o, fixedHeaderHeight: r, headerHeight: s, scrollingInProgress: i, scrollTop: l, viewportHeight: c },
    { scrollToIndex: a }
  ]) => {
    const m = $();
    return O(
      x(
        m,
        N(e, c, n, s, r, o, l),
        N(t),
        E(([[S, g, I, w, v, h, p, u], T]) => {
          const { align: b, behavior: f, calculateViewLocation: d = Do, done: y, ...B } = S, k = _n(S, g, w - 1), L = ie(k, g.offsetTree, T) + v + h, z = L + wt(g.sizeTree, k)[1], _ = u + h, J = u + I - p, nt = d({
            itemBottom: z,
            itemTop: L,
            locationParams: { align: b, behavior: f, ...B },
            viewportBottom: J,
            viewportTop: _
          });
          return nt ? y && Tt(
            x(
              i,
              A((F) => !F),
              // skips the initial publish of false, and the cleanup call.
              // but if scrollingInProgress is true, we skip the initial publish.
              Dt(ot(i) ? 1 : 2)
            ),
            y
          ) : y && y(), nt;
        }),
        A((S) => S !== null)
      ),
      a
    ), {
      scrollIntoView: m
    };
  },
  X(Et, at, ce, $t, Vt),
  { singleton: true }
);
function xn(t) {
  return t ? t === "smooth" ? "smooth" : "auto" : false;
}
var $o = (t, e) => typeof t == "function" ? xn(t(e)) : e && xn(t);
var Uo = U(
  ([
    { listRefresh: t, totalCount: e, fixedItemSize: n, data: o },
    { atBottomState: r, isAtBottom: s },
    { scrollToIndex: i },
    { scrolledToInitialItem: l },
    { didMount: c, propsReady: a },
    { log: m },
    { scrollingInProgress: S },
    { context: g },
    { scrollIntoView: I }
  ]) => {
    const w = C(false), v = $();
    let h = null;
    function p(f) {
      G(i, {
        align: "end",
        behavior: f,
        index: "LAST"
      });
    }
    K(
      x(
        rt(x(V(e), Dt(1)), c),
        N(V(w), s, l, S),
        E(([[f, d], y, B, k, L]) => {
          let z = d && k, _ = "auto";
          return z && (_ = $o(y, B || L), z = z && !!_), { followOutputBehavior: _, shouldFollow: z, totalCount: f };
        }),
        A(({ shouldFollow: f }) => f)
      ),
      ({ followOutputBehavior: f, totalCount: d }) => {
        h && (h(), h = null), ot(n) ? requestAnimationFrame(() => {
          ot(m)("following output to ", { totalCount: d }, mt.DEBUG), p(f);
        }) : h = Tt(t, () => {
          ot(m)("following output to ", { totalCount: d }, mt.DEBUG), p(f), h = null;
        });
      }
    );
    function u(f) {
      const d = Tt(r, (y) => {
        f && !y.atBottom && y.notAtBottomBecause === "SIZE_INCREASED" && !h && (ot(m)("scrolling to bottom due to increased size", {}, mt.DEBUG), p("auto"));
      });
      setTimeout(d, 100);
    }
    K(
      x(
        rt(V(w), e, a),
        A(([f, , d]) => f && d),
        bt(
          ({ value: f }, [, d]) => ({ refreshed: f === d, value: d }),
          { refreshed: false, value: 0 }
        ),
        A(({ refreshed: f }) => f),
        N(w, e)
      ),
      ([, f]) => {
        ot(l) && u(f !== false);
      }
    ), K(v, () => {
      u(ot(w) !== false);
    }), K(rt(V(w), r), ([f, d]) => {
      f && !d.atBottom && d.notAtBottomBecause === "VIEWPORT_HEIGHT_DECREASING" && p("auto");
    });
    const T = C(null), b = $();
    return O(
      Le(
        x(
          V(o),
          E((f) => {
            var d;
            return (d = f == null ? void 0 : f.length) != null ? d : 0;
          })
        ),
        x(V(e))
      ),
      b
    ), K(
      x(
        rt(x(b, Dt(1)), c),
        N(V(T), l, S, g),
        E(([[f, d], y, B, k, L]) => d && B && (y == null ? void 0 : y({ context: L, totalCount: f, scrollingInProgress: k }))),
        A((f) => !!f),
        kt(0)
      ),
      (f) => {
        h && (h(), h = null), ot(n) ? requestAnimationFrame(() => {
          ot(m)("scrolling into view", {}), G(I, f);
        }) : h = Tt(t, () => {
          ot(m)("scrolling into view", {}), G(I, f), h = null;
        });
      }
    ), { autoscrollToBottom: v, followOutput: w, scrollIntoViewOnChange: T };
  },
  X(
    Et,
    ae,
    ce,
    ue,
    Pt,
    Vt,
    at,
    jn,
    qn
  )
);
var Ko = U(
  ([{ data: t, firstItemIndex: e, gap: n, sizes: o }, { initialTopMostItemIndex: r }, { initialItemCount: s, listState: i }, { didMount: l }]) => (O(
    x(
      l,
      N(s),
      A(([, c]) => c !== 0),
      N(r, o, e, n, t),
      E(([[, c], a, m, S, g, I = []]) => Un(c, a, m, S, g, I))
    ),
    i
  ), {}),
  X(Et, ue, $t, Pt),
  { singleton: true }
);
var jo = U(
  ([{ didMount: t }, { scrollTo: e }, { listState: n }]) => {
    const o = C(0);
    return K(
      x(
        t,
        N(o),
        A(([, r]) => r !== 0),
        E(([, r]) => ({ top: r }))
      ),
      (r) => {
        Tt(
          x(
            n,
            Dt(1),
            A((s) => s.items.length > 1)
          ),
          () => {
            requestAnimationFrame(() => {
              G(e, r);
            });
          }
        );
      }
    ), {
      initialScrollTop: o
    };
  },
  X(Pt, at, $t),
  { singleton: true }
);
var Yn = U(
  ([{ scrollVelocity: t }]) => {
    const e = C(false), n = $(), o = C(false);
    return O(
      x(
        t,
        N(o, e, n),
        A(([r, s]) => !!s),
        E(([r, s, i, l]) => {
          const { enter: c, exit: a } = s;
          if (i) {
            if (a(r, l))
              return false;
          } else if (c(r, l))
            return true;
          return i;
        }),
        Z()
      ),
      e
    ), K(
      x(rt(e, t, n), N(o)),
      ([[r, s, i], l]) => {
        r && l && l.change && l.change(s, i);
      }
    ), { isSeeking: e, scrollSeekConfiguration: o, scrollSeekRangeChanged: n, scrollVelocity: t };
  },
  X(ae),
  { singleton: true }
);
var qe = U(([{ scrollContainerState: t, scrollTo: e }]) => {
  const n = $(), o = $(), r = $(), s = C(false), i = C(void 0);
  return O(
    x(
      rt(n, o),
      E(([{ scrollHeight: l, scrollTop: c, viewportHeight: a }, { offsetTop: m }]) => ({
        scrollHeight: l,
        scrollTop: Math.max(0, c - m),
        viewportHeight: a
      }))
    ),
    t
  ), O(
    x(
      e,
      N(o),
      E(([l, { offsetTop: c }]) => ({
        ...l,
        top: l.top + c
      }))
    ),
    r
  ), {
    customScrollParent: i,
    // config
    useWindowScroll: s,
    // input
    windowScrollContainerState: n,
    // signals
    windowScrollTo: r,
    windowViewportRect: o
  };
}, X(at));
var qo = U(
  ([
    { sizeRanges: t, sizes: e },
    { headerHeight: n, scrollTop: o },
    { initialTopMostItemIndex: r },
    { didMount: s },
    { useWindowScroll: i, windowScrollContainerState: l, windowViewportRect: c }
  ]) => {
    const a = $(), m = C(void 0), S = C(null), g = C(null);
    return O(l, S), O(c, g), K(
      x(
        a,
        N(e, o, i, S, g, n)
      ),
      ([I, w, v, h, p, u, T]) => {
        const b = Fo(w.sizeTree);
        h && p !== null && u !== null && (v = p.scrollTop - u.offsetTop), v -= T, I({ ranges: b, scrollTop: v });
      }
    ), O(x(m, A(We), E(Yo)), r), O(
      x(
        s,
        N(m),
        A(([, I]) => I !== void 0),
        Z(),
        E(([, I]) => I.ranges)
      ),
      t
    ), {
      getState: a,
      restoreStateFrom: m
    };
  },
  X(Et, at, ue, Pt, qe)
);
function Yo(t) {
  return { align: "start", index: 0, offset: t.scrollTop };
}
var Zo = U(([{ topItemsIndexes: t }]) => {
  const e = C(0);
  return O(
    x(
      e,
      A((n) => n >= 0),
      E((n) => Array.from({ length: n }).map((o, r) => r))
    ),
    t
  ), { topItemCount: e };
}, X($t));
function Zn(t) {
  let e = false, n;
  return () => (e || (e = true, n = t()), n);
}
var Xo = Zn(() => /iP(ad|od|hone)/i.test(navigator.userAgent) && /WebKit/i.test(navigator.userAgent));
var Jo = U(
  ([
    { deviation: t, scrollBy: e, scrollingInProgress: n, scrollTop: o },
    { isAtBottom: r, isScrolling: s, lastJumpDueToItemResize: i, scrollDirection: l },
    { listState: c },
    { beforeUnshiftWith: a, gap: m, shiftWithOffset: S, sizes: g },
    { log: I },
    { recalcInProgress: w }
  ]) => {
    const v = ht(
      x(
        c,
        N(i),
        bt(
          ([, p, u, T], [{ bottom: b, items: f, offsetBottom: d, totalCount: y }, B]) => {
            const k = b + d;
            let L = 0;
            return u === y && p.length > 0 && f.length > 0 && (f[0].originalIndex === 0 && p[0].originalIndex === 0 || (L = k - T, L !== 0 && (L += B))), [L, f, y, k];
          },
          [0, [], 0, 0]
        ),
        A(([p]) => p !== 0),
        N(o, l, n, r, I, w),
        A(([, p, u, T, , , b]) => !b && !T && p !== 0 && u === le),
        E(([[p], , , , , u]) => (u("Upward scrolling compensation", { amount: p }, mt.DEBUG), p))
      )
    );
    function h(p) {
      p > 0 ? (G(e, { behavior: "auto", top: -p }), G(t, 0)) : (G(t, 0), G(e, { behavior: "auto", top: -p }));
    }
    return K(x(v, N(t, s)), ([p, u, T]) => {
      T && Xo() ? G(t, u - p) : h(-p);
    }), K(
      x(
        rt(ct(s, false), t, w),
        A(([p, u, T]) => !p && !T && u !== 0),
        E(([p, u]) => u),
        kt(1)
      ),
      h
    ), O(
      x(
        S,
        E((p) => ({ top: -p }))
      ),
      e
    ), K(
      x(
        a,
        N(g, m),
        E(([p, { groupIndices: u, lastSize: T, sizeTree: b }, f]) => {
          function d(y) {
            return y * (T + f);
          }
          if (u.length === 0)
            return d(p);
          {
            let y = 0;
            const B = re(b, 0);
            let k = 0, L = 0;
            for (; k < p; ) {
              k++, y += B;
              let z = u.length === L + 1 ? 1 / 0 : u[L + 1] - u[L] - 1;
              k + z > p && (y -= B, z = p - k + 1), k += z, y += d(z), L++;
            }
            return y;
          }
        })
      ),
      (p) => {
        G(t, p), requestAnimationFrame(() => {
          G(e, { top: p }), requestAnimationFrame(() => {
            G(t, 0), G(w, false);
          });
        });
      }
    ), { deviation: t };
  },
  X(at, ae, $t, Et, Vt, De)
);
var Qo = U(
  ([
    t,
    e,
    n,
    o,
    r,
    s,
    i,
    l,
    c,
    a,
    m
  ]) => ({
    ...t,
    ...e,
    ...n,
    ...o,
    ...r,
    ...s,
    ...i,
    ...l,
    ...c,
    ...a,
    ...m
  }),
  X(
    je,
    Ko,
    Pt,
    Yn,
    Kn,
    jo,
    No,
    qe,
    qn,
    Vt,
    jn
  )
);
var Xn = U(
  ([
    {
      data: t,
      defaultItemSize: e,
      firstItemIndex: n,
      fixedItemSize: o,
      gap: r,
      groupIndices: s,
      itemSize: i,
      sizeRanges: l,
      sizes: c,
      statefulTotalCount: a,
      totalCount: m,
      trackItemSizes: S
    },
    { initialItemFinalLocationReached: g, initialTopMostItemIndex: I, scrolledToInitialItem: w },
    v,
    h,
    p,
    { listState: u, topItemsIndexes: T, ...b },
    { scrollToIndex: f },
    d,
    { topItemCount: y },
    { groupCounts: B },
    k
  ]) => (O(b.rangeChanged, k.scrollSeekRangeChanged), O(
    x(
      k.windowViewportRect,
      E((L) => L.visibleHeight)
    ),
    v.viewportHeight
  ), {
    data: t,
    defaultItemHeight: e,
    firstItemIndex: n,
    fixedItemHeight: o,
    gap: r,
    groupCounts: B,
    initialItemFinalLocationReached: g,
    initialTopMostItemIndex: I,
    scrolledToInitialItem: w,
    sizeRanges: l,
    topItemCount: y,
    topItemsIndexes: T,
    // input
    totalCount: m,
    ...p,
    groupIndices: s,
    itemSize: i,
    listState: u,
    scrollToIndex: f,
    // output
    statefulTotalCount: a,
    trackItemSizes: S,
    // exported from stateFlagsSystem
    ...b,
    // the bag of IO from featureGroup1System
    ...k,
    ...v,
    sizes: c,
    ...h
  }),
  X(
    Et,
    ue,
    at,
    qo,
    Uo,
    $t,
    ce,
    Jo,
    Zo,
    Nn,
    Qo
  )
);
function tr(t, e) {
  const n = {}, o = {};
  let r = 0;
  const s = t.length;
  for (; r < s; )
    o[t[r]] = 1, r += 1;
  for (const i in e)
    Object.hasOwn(o, i) || (n[i] = e[i]);
  return n;
}
var pe = typeof document < "u" ? import_react.default.useLayoutEffect : import_react.default.useEffect;
function Ye(t, e, n) {
  const o = Object.keys(e.required || {}), r = Object.keys(e.optional || {}), s = Object.keys(e.methods || {}), i = Object.keys(e.events || {}), l = import_react.default.createContext({});
  function c(p, u) {
    p.propsReady && G(p.propsReady, false);
    for (const T of o) {
      const b = p[e.required[T]];
      G(b, u[T]);
    }
    for (const T of r)
      if (T in u) {
        const b = p[e.optional[T]];
        G(b, u[T]);
      }
    p.propsReady && G(p.propsReady, true);
  }
  function a(p) {
    return s.reduce((u, T) => (u[T] = (b) => {
      const f = p[e.methods[T]];
      G(f, b);
    }, u), {});
  }
  function m(p) {
    return i.reduce((u, T) => (u[T] = Io(p[e.events[T]]), u), {});
  }
  const S = import_react.default.forwardRef((p, u) => {
    const { children: T, ...b } = p, [f] = import_react.default.useState(() => ve(xo(t), (B) => {
      c(B, b);
    })), [d] = import_react.default.useState(an(m, f));
    pe(() => {
      for (const B of i)
        B in b && K(d[B], b[B]);
      return () => {
        Object.values(d).map(Ge);
      };
    }, [b, d, f]), pe(() => {
      c(f, b);
    }), import_react.default.useImperativeHandle(u, un(a(f)));
    const y = n;
    return (0, import_jsx_runtime.jsx)(l.Provider, { value: f, children: n ? (0, import_jsx_runtime.jsx)(y, { ...tr([...o, ...r, ...i], b), children: T }) : T });
  }), g = (p) => {
    const u = import_react.default.useContext(l);
    return import_react.default.useCallback(
      (T) => {
        G(u[p], T);
      },
      [u, p]
    );
  }, I = (p) => {
    const T = import_react.default.useContext(l)[p], b = import_react.default.useCallback(
      (f) => K(T, f),
      [T]
    );
    return import_react.default.useSyncExternalStore(
      b,
      () => ot(T),
      () => ot(T)
    );
  }, w = (p) => {
    const T = import_react.default.useContext(l)[p], [b, f] = import_react.default.useState(an(ot, T));
    return pe(
      () => K(T, (d) => {
        d !== b && f(un(d));
      }),
      [T, b]
    ), b;
  }, v = import_react.default.version.startsWith("18") ? I : w;
  return {
    Component: S,
    useEmitter: (p, u) => {
      const b = import_react.default.useContext(l)[p];
      pe(() => K(b, u), [u, b]);
    },
    useEmitterValue: v,
    usePublisher: g
  };
}
var be = import_react.default.createContext(void 0);
var Jn = import_react.default.createContext(void 0);
var Qn = typeof document < "u" ? import_react.default.useLayoutEffect : import_react.default.useEffect;
function ke(t) {
  return "self" in t;
}
function er(t) {
  return "body" in t;
}
function to(t, e, n, o = Yt, r, s) {
  const i = import_react.default.useRef(null), l = import_react.default.useRef(null), c = import_react.default.useRef(null), a = import_react.default.useCallback(
    (g) => {
      let I, w, v;
      const h = g.target;
      if (er(h) || ke(h)) {
        const u = ke(h) ? h : h.defaultView;
        v = s ? u.scrollX : u.scrollY, I = s ? u.document.documentElement.scrollWidth : u.document.documentElement.scrollHeight, w = s ? u.innerWidth : u.innerHeight;
      } else
        v = s ? h.scrollLeft : h.scrollTop, I = s ? h.scrollWidth : h.scrollHeight, w = s ? h.offsetWidth : h.offsetHeight;
      const p = () => {
        t({
          scrollHeight: I,
          scrollTop: Math.max(v, 0),
          viewportHeight: w
        });
      };
      g.suppressFlushSync ? p() : import_react_dom.default.flushSync(p), l.current !== null && (v === l.current || v <= 0 || v === I - w) && (l.current = null, e(true), c.current && (clearTimeout(c.current), c.current = null));
    },
    [t, e, s]
  );
  import_react.default.useEffect(() => {
    const g = r || i.current;
    return o(r || i.current), a({ suppressFlushSync: true, target: g }), g.addEventListener("scroll", a, { passive: true }), () => {
      o(null), g.removeEventListener("scroll", a);
    };
  }, [i, a, n, o, r]);
  function m(g) {
    const I = i.current;
    if (!I || (s ? "offsetWidth" in I && I.offsetWidth === 0 : "offsetHeight" in I && I.offsetHeight === 0))
      return;
    const w = g.behavior === "smooth";
    let v, h, p;
    ke(I) ? (h = Math.max(
      vt(I.document.documentElement, s ? "width" : "height"),
      s ? I.document.documentElement.scrollWidth : I.document.documentElement.scrollHeight
    ), v = s ? I.innerWidth : I.innerHeight, p = s ? window.scrollX : window.scrollY) : (h = I[s ? "scrollWidth" : "scrollHeight"], v = vt(I, s ? "width" : "height"), p = I[s ? "scrollLeft" : "scrollTop"]);
    const u = h - v;
    if (g.top = Math.ceil(Math.max(Math.min(u, g.top), 0)), $n(v, h) || g.top === p) {
      t({ scrollHeight: h, scrollTop: p, viewportHeight: v }), w && e(true);
      return;
    }
    w ? (l.current = g.top, c.current && clearTimeout(c.current), c.current = setTimeout(() => {
      c.current = null, l.current = null, e(true);
    }, 1e3)) : l.current = null, s && (g = { behavior: g.behavior, left: g.top }), I.scrollTo(g);
  }
  function S(g) {
    s && (g = { behavior: g.behavior, left: g.top }), i.current.scrollBy(g);
  }
  return { scrollByCallback: S, scrollerRef: i, scrollToCallback: m };
}
var Fe = "-webkit-sticky";
var Tn = "sticky";
var Ze = Zn(() => {
  if (typeof document > "u")
    return Tn;
  const t = document.createElement("div");
  return t.style.position = Fe, t.style.position === Fe ? Fe : Tn;
});
function Xe(t) {
  return t;
}
var nr = U(() => {
  const t = C((l) => `Item ${l}`), e = C((l) => `Group ${l}`), n = C({}), o = C(Xe), r = C("div"), s = C(Yt), i = (l, c = null) => ct(
    x(
      n,
      E((a) => a[l]),
      Z()
    ),
    c
  );
  return {
    components: n,
    computeItemKey: o,
    EmptyPlaceholder: i("EmptyPlaceholder"),
    FooterComponent: i("Footer"),
    GroupComponent: i("Group", "div"),
    groupContent: e,
    HeaderComponent: i("Header"),
    HeaderFooterTag: r,
    ItemComponent: i("Item", "div"),
    itemContent: t,
    ListComponent: i("List", "div"),
    ScrollerComponent: i("Scroller", "div"),
    scrollerRef: s,
    ScrollSeekPlaceholder: i("ScrollSeekPlaceholder"),
    TopItemListComponent: i("TopItemList")
  };
});
var or = U(
  ([t, e]) => ({ ...t, ...e }),
  X(Xn, nr)
);
var rr = ({ height: t }) => (0, import_jsx_runtime.jsx)("div", { style: { height: t } });
var sr = { overflowAnchor: "none", position: Ze(), zIndex: 1 };
var eo = { overflowAnchor: "none" };
var ir = { ...eo, display: "inline-block", height: "100%" };
var Cn = import_react.default.memo(function({ showTopList: e = false }) {
  const n = M("listState"), o = gt("sizeRanges"), r = M("useWindowScroll"), s = M("customScrollParent"), i = gt("windowScrollContainerState"), l = gt("scrollContainerState"), c = s || r ? i : l, a = M("itemContent"), m = M("context"), S = M("groupContent"), g = M("trackItemSizes"), I = M("itemSize"), w = M("log"), v = gt("gap"), h = M("horizontalDirection"), { callbackRef: p } = On(
    o,
    I,
    g,
    e ? Yt : c,
    w,
    v,
    s,
    h,
    M("skipAnimationFrameInResizeObserver")
  ), [u, T] = import_react.default.useState(0);
  tn("deviation", (F) => {
    u !== F && T(F);
  });
  const b = M("EmptyPlaceholder"), f = M("ScrollSeekPlaceholder") || rr, d = M("ListComponent"), y = M("ItemComponent"), B = M("GroupComponent"), k = M("computeItemKey"), L = M("isSeeking"), z = M("groupIndices").length > 0, _ = M("alignToBottom"), J = M("initialItemFinalLocationReached"), nt = e ? {} : {
    boxSizing: "border-box",
    ...h ? {
      display: "inline-block",
      height: "100%",
      marginLeft: u !== 0 ? u : _ ? "auto" : 0,
      paddingLeft: n.offsetTop,
      paddingRight: n.offsetBottom,
      whiteSpace: "nowrap"
    } : {
      marginTop: u !== 0 ? u : _ ? "auto" : 0,
      paddingBottom: n.offsetBottom,
      paddingTop: n.offsetTop
    },
    ...J ? {} : { visibility: "hidden" }
  };
  return !e && n.totalCount === 0 && b ? (0, import_jsx_runtime.jsx)(b, { ...q(b, m) }) : (0, import_jsx_runtime.jsx)(
    d,
    {
      ...q(d, m),
      "data-testid": e ? "virtuoso-top-item-list" : "virtuoso-item-list",
      ref: p,
      style: nt,
      children: (e ? n.topItems : n.items).map((F) => {
        const Y = F.originalIndex, it = k(Y + n.firstItemIndex, F.data, m);
        return L ? (0, import_react.createElement)(
          f,
          {
            ...q(f, m),
            height: F.size,
            index: F.index,
            key: it,
            type: F.type || "item",
            ...F.type === "group" ? {} : { groupIndex: F.groupIndex }
          }
        ) : F.type === "group" ? (0, import_react.createElement)(
          B,
          {
            ...q(B, m),
            "data-index": Y,
            "data-item-index": F.index,
            "data-known-size": F.size,
            key: it,
            style: sr
          },
          S(F.index, m)
        ) : (0, import_react.createElement)(
          y,
          {
            ...q(y, m),
            ...no(y, F.data),
            "data-index": Y,
            "data-item-group-index": F.groupIndex,
            "data-item-index": F.index,
            "data-known-size": F.size,
            key: it,
            style: h ? ir : eo
          },
          z ? a(F.index, F.groupIndex, F.data, m) : a(F.index, F.data, m)
        );
      })
    }
  );
});
var lr = {
  height: "100%",
  outline: "none",
  overflowY: "auto",
  position: "relative",
  WebkitOverflowScrolling: "touch"
};
var cr = {
  outline: "none",
  overflowX: "auto",
  position: "relative"
};
var Zt = (t) => ({
  height: "100%",
  position: "absolute",
  top: 0,
  width: "100%",
  ...t ? { display: "flex", flexDirection: "column" } : {}
});
var ur = {
  position: Ze(),
  top: 0,
  width: "100%",
  zIndex: 1
};
function q(t, e) {
  if (typeof t != "string")
    return { context: e };
}
function no(t, e) {
  return { item: typeof t == "string" ? void 0 : e };
}
var ar = import_react.default.memo(function() {
  const e = M("HeaderComponent"), n = gt("headerHeight"), o = M("HeaderFooterTag"), r = Ht(
    import_react.default.useMemo(
      () => (i) => {
        n(vt(i, "height"));
      },
      [n]
    ),
    true,
    M("skipAnimationFrameInResizeObserver")
  ), s = M("context");
  return e ? (0, import_jsx_runtime.jsx)(o, { ref: r, children: (0, import_jsx_runtime.jsx)(e, { ...q(e, s) }) }) : null;
});
var dr = import_react.default.memo(function() {
  const e = M("FooterComponent"), n = gt("footerHeight"), o = M("HeaderFooterTag"), r = Ht(
    import_react.default.useMemo(
      () => (i) => {
        n(vt(i, "height"));
      },
      [n]
    ),
    true,
    M("skipAnimationFrameInResizeObserver")
  ), s = M("context");
  return e ? (0, import_jsx_runtime.jsx)(o, { ref: r, children: (0, import_jsx_runtime.jsx)(e, { ...q(e, s) }) }) : null;
});
function Je({ useEmitter: t, useEmitterValue: e, usePublisher: n }) {
  return import_react.default.memo(function({ children: s, style: i, ...l }) {
    const c = n("scrollContainerState"), a = e("ScrollerComponent"), m = n("smoothScrollTargetReached"), S = e("scrollerRef"), g = e("context"), I = e("horizontalDirection") || false, { scrollByCallback: w, scrollerRef: v, scrollToCallback: h } = to(
      c,
      m,
      a,
      S,
      void 0,
      I
    );
    return t("scrollTo", h), t("scrollBy", w), (0, import_jsx_runtime.jsx)(
      a,
      {
        "data-testid": "virtuoso-scroller",
        "data-virtuoso-scroller": true,
        ref: v,
        style: { ...I ? cr : lr, ...i },
        tabIndex: 0,
        ...l,
        ...q(a, g),
        children: s
      }
    );
  });
}
function Qe({ useEmitter: t, useEmitterValue: e, usePublisher: n }) {
  return import_react.default.memo(function({ children: s, style: i, ...l }) {
    const c = n("windowScrollContainerState"), a = e("ScrollerComponent"), m = n("smoothScrollTargetReached"), S = e("totalListHeight"), g = e("deviation"), I = e("customScrollParent"), w = e("context"), v = import_react.default.useRef(null), h = e("scrollerRef"), { scrollByCallback: p, scrollerRef: u, scrollToCallback: T } = to(
      c,
      m,
      a,
      h,
      I
    );
    return Qn(() => {
      var b;
      return u.current = I || ((b = v.current) == null ? void 0 : b.ownerDocument.defaultView), () => {
        u.current = null;
      };
    }, [u, I]), t("windowScrollTo", T), t("scrollBy", p), (0, import_jsx_runtime.jsx)(
      a,
      {
        ref: v,
        "data-virtuoso-scroller": true,
        style: { position: "relative", ...i, ...S !== 0 ? { height: S + g } : {} },
        ...l,
        ...q(a, w),
        children: s
      }
    );
  });
}
var fr = ({ children: t }) => {
  const e = import_react.default.useContext(be), n = gt("viewportHeight"), o = gt("fixedItemHeight"), r = M("alignToBottom"), s = M("horizontalDirection"), i = import_react.default.useMemo(
    () => ne(n, (c) => vt(c, s ? "width" : "height")),
    [n, s]
  ), l = Ht(i, true, M("skipAnimationFrameInResizeObserver"));
  return import_react.default.useEffect(() => {
    e && (n(e.viewportHeight), o(e.itemHeight));
  }, [e, n, o]), (0, import_jsx_runtime.jsx)("div", { "data-viewport-type": "element", ref: l, style: Zt(r), children: t });
};
var mr = ({ children: t }) => {
  const e = import_react.default.useContext(be), n = gt("windowViewportRect"), o = gt("fixedItemHeight"), r = M("customScrollParent"), s = Ne(
    n,
    r,
    M("skipAnimationFrameInResizeObserver")
  ), i = M("alignToBottom");
  return import_react.default.useEffect(() => {
    e && (o(e.itemHeight), n({ offsetTop: 0, visibleHeight: e.viewportHeight, visibleWidth: 100 }));
  }, [e, n, o]), (0, import_jsx_runtime.jsx)("div", { "data-viewport-type": "window", ref: s, style: Zt(i), children: t });
};
var pr = ({ children: t }) => {
  const e = M("TopItemListComponent") || "div", n = M("headerHeight"), o = { ...ur, marginTop: `${n}px` }, r = M("context");
  return (0, import_jsx_runtime.jsx)(e, { style: o, ...q(e, r), children: t });
};
var hr = import_react.default.memo(function(e) {
  const n = M("useWindowScroll"), o = M("topItemsIndexes").length > 0, r = M("customScrollParent"), s = M("context"), i = r || n ? Ir : gr, l = r || n ? mr : fr;
  return (0, import_jsx_runtime.jsxs)(i, { ...e, ...q(i, s), children: [
    o && (0, import_jsx_runtime.jsx)(pr, { children: (0, import_jsx_runtime.jsx)(Cn, { showTopList: true }) }),
    (0, import_jsx_runtime.jsxs)(l, { children: [
      (0, import_jsx_runtime.jsx)(ar, {}),
      (0, import_jsx_runtime.jsx)(Cn, {}),
      (0, import_jsx_runtime.jsx)(dr, {})
    ] })
  ] });
});
var {
  Component: oo,
  useEmitter: tn,
  useEmitterValue: M,
  usePublisher: gt
} = Ye(
  or,
  {
    required: {},
    optional: {
      restoreStateFrom: "restoreStateFrom",
      context: "context",
      followOutput: "followOutput",
      scrollIntoViewOnChange: "scrollIntoViewOnChange",
      itemContent: "itemContent",
      groupContent: "groupContent",
      overscan: "overscan",
      increaseViewportBy: "increaseViewportBy",
      totalCount: "totalCount",
      groupCounts: "groupCounts",
      topItemCount: "topItemCount",
      firstItemIndex: "firstItemIndex",
      initialTopMostItemIndex: "initialTopMostItemIndex",
      components: "components",
      atBottomThreshold: "atBottomThreshold",
      atTopThreshold: "atTopThreshold",
      computeItemKey: "computeItemKey",
      defaultItemHeight: "defaultItemHeight",
      fixedItemHeight: "fixedItemHeight",
      itemSize: "itemSize",
      scrollSeekConfiguration: "scrollSeekConfiguration",
      headerFooterTag: "HeaderFooterTag",
      data: "data",
      initialItemCount: "initialItemCount",
      initialScrollTop: "initialScrollTop",
      alignToBottom: "alignToBottom",
      useWindowScroll: "useWindowScroll",
      customScrollParent: "customScrollParent",
      scrollerRef: "scrollerRef",
      logLevel: "logLevel",
      horizontalDirection: "horizontalDirection",
      skipAnimationFrameInResizeObserver: "skipAnimationFrameInResizeObserver"
    },
    methods: {
      scrollToIndex: "scrollToIndex",
      scrollIntoView: "scrollIntoView",
      scrollTo: "scrollTo",
      scrollBy: "scrollBy",
      autoscrollToBottom: "autoscrollToBottom",
      getState: "getState"
    },
    events: {
      isScrolling: "isScrolling",
      endReached: "endReached",
      startReached: "startReached",
      rangeChanged: "rangeChanged",
      atBottomStateChange: "atBottomStateChange",
      atTopStateChange: "atTopStateChange",
      totalListHeightChanged: "totalListHeightChanged",
      itemsRendered: "itemsRendered",
      groupIndices: "groupIndices"
    }
  },
  hr
);
var gr = Je({ useEmitter: tn, useEmitterValue: M, usePublisher: gt });
var Ir = Qe({ useEmitter: tn, useEmitterValue: M, usePublisher: gt });
var qr = oo;
var Yr = oo;
var Sr = U(() => {
  const t = C((a) => (0, import_jsx_runtime.jsxs)("td", { children: [
    "Item $",
    a
  ] })), e = C(null), n = C((a) => (0, import_jsx_runtime.jsxs)("td", { colSpan: 1e3, children: [
    "Group ",
    a
  ] })), o = C(null), r = C(null), s = C({}), i = C(Xe), l = C(Yt), c = (a, m = null) => ct(
    x(
      s,
      E((S) => S[a]),
      Z()
    ),
    m
  );
  return {
    components: s,
    computeItemKey: i,
    context: e,
    EmptyPlaceholder: c("EmptyPlaceholder"),
    FillerRow: c("FillerRow"),
    fixedFooterContent: r,
    fixedHeaderContent: o,
    itemContent: t,
    groupContent: n,
    ScrollerComponent: c("Scroller", "div"),
    scrollerRef: l,
    ScrollSeekPlaceholder: c("ScrollSeekPlaceholder"),
    TableBodyComponent: c("TableBody", "tbody"),
    TableComponent: c("Table", "table"),
    TableFooterComponent: c("TableFoot", "tfoot"),
    TableHeadComponent: c("TableHead", "thead"),
    TableRowComponent: c("TableRow", "tr"),
    GroupComponent: c("Group", "tr")
  };
});
var xr = U(
  ([t, e]) => ({ ...t, ...e }),
  X(Xn, Sr)
);
var Tr = ({ height: t }) => (0, import_jsx_runtime.jsx)("tr", { children: (0, import_jsx_runtime.jsx)("td", { style: { height: t } }) });
var Cr = ({ height: t }) => (0, import_jsx_runtime.jsx)("tr", { children: (0, import_jsx_runtime.jsx)("td", { style: { border: 0, height: t, padding: 0 } }) });
var wr = { overflowAnchor: "none" };
var wn = { position: Ze(), zIndex: 2, overflowAnchor: "none" };
var vn = import_react.default.memo(function({ showTopList: e = false }) {
  const n = W("listState"), o = W("computeItemKey"), r = W("firstItemIndex"), s = W("context"), i = W("isSeeking"), l = W("fixedHeaderHeight"), c = W("groupIndices").length > 0, a = W("itemContent"), m = W("groupContent"), S = W("ScrollSeekPlaceholder") || Tr, g = W("GroupComponent"), I = W("TableRowComponent"), w = (e ? n.topItems : []).reduce((h, p, u) => (u === 0 ? h.push(p.size) : h.push(h[u - 1] + p.size), h), []), v = (e ? n.topItems : n.items).map((h) => {
    const p = h.originalIndex, u = o(p + r, h.data, s), T = e ? p === 0 ? 0 : w[p - 1] : 0;
    return i ? (0, import_react.createElement)(
      S,
      {
        ...q(S, s),
        height: h.size,
        index: h.index,
        key: u,
        type: h.type || "item"
      }
    ) : h.type === "group" ? (0, import_react.createElement)(
      g,
      {
        ...q(g, s),
        "data-index": p,
        "data-item-index": h.index,
        "data-known-size": h.size,
        key: u,
        style: {
          ...wn,
          top: l
        }
      },
      m(h.index, s)
    ) : (0, import_react.createElement)(
      I,
      {
        ...q(I, s),
        ...no(I, h.data),
        "data-index": p,
        "data-item-index": h.index,
        "data-known-size": h.size,
        "data-item-group-index": h.groupIndex,
        key: u,
        style: e ? { ...wn, top: l + T } : wr
      },
      c ? a(h.index, h.groupIndex, h.data, s) : a(h.index, h.data, s)
    );
  });
  return (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: v });
});
var vr = import_react.default.memo(function() {
  const e = W("listState"), n = W("topItemsIndexes").length > 0, o = Ct("sizeRanges"), r = W("useWindowScroll"), s = W("customScrollParent"), i = Ct("windowScrollContainerState"), l = Ct("scrollContainerState"), c = s || r ? i : l, a = W("trackItemSizes"), m = W("itemSize"), S = W("log"), { callbackRef: g, ref: I } = On(
    o,
    m,
    a,
    c,
    S,
    void 0,
    s,
    false,
    W("skipAnimationFrameInResizeObserver")
  ), [w, v] = import_react.default.useState(0);
  en("deviation", (z) => {
    w !== z && (I.current.style.marginTop = `${z}px`, v(z));
  });
  const h = W("EmptyPlaceholder"), p = W("FillerRow") || Cr, u = W("TableBodyComponent"), T = W("paddingTopAddition"), b = W("statefulTotalCount"), f = W("context");
  if (b === 0 && h)
    return (0, import_jsx_runtime.jsx)(h, { ...q(h, f) });
  const d = (n ? e.topItems : []).reduce((z, _) => z + _.size, 0), y = e.offsetTop + T + w - d, B = e.offsetBottom, k = y > 0 ? (0, import_jsx_runtime.jsx)(p, { context: f, height: y }, "padding-top") : null, L = B > 0 ? (0, import_jsx_runtime.jsx)(p, { context: f, height: B }, "padding-bottom") : null;
  return (0, import_jsx_runtime.jsxs)(u, { "data-testid": "virtuoso-item-list", ref: g, ...q(u, f), children: [
    k,
    n && (0, import_jsx_runtime.jsx)(vn, { showTopList: true }),
    (0, import_jsx_runtime.jsx)(vn, {}),
    L
  ] });
});
var yr = ({ children: t }) => {
  const e = import_react.default.useContext(be), n = Ct("viewportHeight"), o = Ct("fixedItemHeight"), r = Ht(
    import_react.default.useMemo(() => ne(n, (s) => vt(s, "height")), [n]),
    true,
    W("skipAnimationFrameInResizeObserver")
  );
  return import_react.default.useEffect(() => {
    e && (n(e.viewportHeight), o(e.itemHeight));
  }, [e, n, o]), (0, import_jsx_runtime.jsx)("div", { "data-viewport-type": "element", ref: r, style: Zt(false), children: t });
};
var Rr = ({ children: t }) => {
  const e = import_react.default.useContext(be), n = Ct("windowViewportRect"), o = Ct("fixedItemHeight"), r = W("customScrollParent"), s = Ne(
    n,
    r,
    W("skipAnimationFrameInResizeObserver")
  );
  return import_react.default.useEffect(() => {
    e && (o(e.itemHeight), n({ offsetTop: 0, visibleHeight: e.viewportHeight, visibleWidth: 100 }));
  }, [e, n, o]), (0, import_jsx_runtime.jsx)("div", { "data-viewport-type": "window", ref: s, style: Zt(false), children: t });
};
var br = import_react.default.memo(function(e) {
  const n = W("useWindowScroll"), o = W("customScrollParent"), r = Ct("fixedHeaderHeight"), s = Ct("fixedFooterHeight"), i = W("fixedHeaderContent"), l = W("fixedFooterContent"), c = W("context"), a = Ht(
    import_react.default.useMemo(() => ne(r, (u) => vt(u, "height")), [r]),
    true,
    W("skipAnimationFrameInResizeObserver")
  ), m = Ht(
    import_react.default.useMemo(() => ne(s, (u) => vt(u, "height")), [s]),
    true,
    W("skipAnimationFrameInResizeObserver")
  ), S = o || n ? Er : Hr, g = o || n ? Rr : yr, I = W("TableComponent"), w = W("TableHeadComponent"), v = W("TableFooterComponent"), h = i ? (0, import_jsx_runtime.jsx)(
    w,
    {
      ref: a,
      style: { position: "sticky", top: 0, zIndex: 2 },
      ...q(w, c),
      children: i()
    },
    "TableHead"
  ) : null, p = l ? (0, import_jsx_runtime.jsx)(
    v,
    {
      ref: m,
      style: { bottom: 0, position: "sticky", zIndex: 1 },
      ...q(v, c),
      children: l()
    },
    "TableFoot"
  ) : null;
  return (0, import_jsx_runtime.jsx)(S, { ...e, ...q(S, c), children: (0, import_jsx_runtime.jsx)(g, { children: (0, import_jsx_runtime.jsxs)(I, { style: { borderSpacing: 0, overflowAnchor: "none" }, ...q(I, c), children: [
    h,
    (0, import_jsx_runtime.jsx)(vr, {}, "TableBody"),
    p
  ] }) }) });
});
var {
  Component: ro,
  useEmitter: en,
  useEmitterValue: W,
  usePublisher: Ct
} = Ye(
  xr,
  {
    required: {},
    optional: {
      restoreStateFrom: "restoreStateFrom",
      context: "context",
      followOutput: "followOutput",
      firstItemIndex: "firstItemIndex",
      itemContent: "itemContent",
      groupContent: "groupContent",
      fixedHeaderContent: "fixedHeaderContent",
      fixedFooterContent: "fixedFooterContent",
      overscan: "overscan",
      increaseViewportBy: "increaseViewportBy",
      totalCount: "totalCount",
      topItemCount: "topItemCount",
      initialTopMostItemIndex: "initialTopMostItemIndex",
      components: "components",
      groupCounts: "groupCounts",
      atBottomThreshold: "atBottomThreshold",
      atTopThreshold: "atTopThreshold",
      computeItemKey: "computeItemKey",
      defaultItemHeight: "defaultItemHeight",
      fixedItemHeight: "fixedItemHeight",
      itemSize: "itemSize",
      scrollSeekConfiguration: "scrollSeekConfiguration",
      data: "data",
      initialItemCount: "initialItemCount",
      initialScrollTop: "initialScrollTop",
      alignToBottom: "alignToBottom",
      useWindowScroll: "useWindowScroll",
      customScrollParent: "customScrollParent",
      scrollerRef: "scrollerRef",
      logLevel: "logLevel"
    },
    methods: {
      scrollToIndex: "scrollToIndex",
      scrollIntoView: "scrollIntoView",
      scrollTo: "scrollTo",
      scrollBy: "scrollBy",
      getState: "getState"
    },
    events: {
      isScrolling: "isScrolling",
      endReached: "endReached",
      startReached: "startReached",
      rangeChanged: "rangeChanged",
      atBottomStateChange: "atBottomStateChange",
      atTopStateChange: "atTopStateChange",
      totalListHeightChanged: "totalListHeightChanged",
      itemsRendered: "itemsRendered",
      groupIndices: "groupIndices"
    }
  },
  br
);
var Hr = Je({ useEmitter: en, useEmitterValue: W, usePublisher: Ct });
var Er = Qe({ useEmitter: en, useEmitterValue: W, usePublisher: Ct });
var Zr = ro;
var Xr = ro;
var yn = {
  bottom: 0,
  itemHeight: 0,
  items: [],
  itemWidth: 0,
  offsetBottom: 0,
  offsetTop: 0,
  top: 0
};
var Br = {
  bottom: 0,
  itemHeight: 0,
  items: [{ index: 0 }],
  itemWidth: 0,
  offsetBottom: 0,
  offsetTop: 0,
  top: 0
};
var { ceil: Rn, floor: Ce, max: ee, min: Oe, round: bn } = Math;
function Hn(t, e, n) {
  return Array.from({ length: e - t + 1 }).map((o, r) => ({ data: n === null ? null : n[r + t], index: r + t }));
}
function kr(t) {
  return {
    ...Br,
    items: t
  };
}
function he(t, e) {
  return t && t.width === e.width && t.height === e.height;
}
function Fr(t, e) {
  return t && t.column === e.column && t.row === e.row;
}
var Or = U(
  ([
    { increaseViewportBy: t, listBoundary: e, overscan: n, visibleRange: o },
    { footerHeight: r, headerHeight: s, scrollBy: i, scrollContainerState: l, scrollTo: c, scrollTop: a, smoothScrollTargetReached: m, viewportHeight: S },
    g,
    I,
    { didMount: w, propsReady: v },
    { customScrollParent: h, useWindowScroll: p, windowScrollContainerState: u, windowScrollTo: T, windowViewportRect: b },
    f
  ]) => {
    const d = C(0), y = C(0), B = C(yn), k = C({ height: 0, width: 0 }), L = C({ height: 0, width: 0 }), z = $(), _ = $(), J = C(0), nt = C(null), F = C({ column: 0, row: 0 }), Y = $(), it = $(), dt = C(false), St = C(0), ft = C(true), ut = C(false), At = C(false);
    K(
      x(
        w,
        N(St),
        A(([R, D]) => !!D)
      ),
      () => {
        G(ft, false);
      }
    ), K(
      x(
        rt(w, ft, L, k, St, ut),
        A(([R, D, Q, lt, , tt]) => R && !D && Q.height !== 0 && lt.height !== 0 && !tt)
      ),
      ([, , , , R]) => {
        G(ut, true), Ue(1, () => {
          G(z, R);
        }), Tt(x(a), () => {
          G(e, [0, 0]), G(ft, true);
        });
      }
    ), O(
      x(
        it,
        A((R) => R != null && R.scrollTop > 0),
        Rt(0)
      ),
      y
    ), K(
      x(
        w,
        N(it),
        A(([, R]) => R != null)
      ),
      ([, R]) => {
        R && (G(k, R.viewport), G(L, R.item), G(F, R.gap), R.scrollTop > 0 && (G(dt, true), Tt(x(a, Dt(1)), (D) => {
          G(dt, false);
        }), G(c, { top: R.scrollTop })));
      }
    ), O(
      x(
        k,
        E(({ height: R }) => R)
      ),
      S
    ), O(
      x(
        rt(
          V(k, he),
          V(L, he),
          V(F, (R, D) => R && R.column === D.column && R.row === D.row),
          V(a)
        ),
        E(([R, D, Q, lt]) => ({
          gap: Q,
          item: D,
          scrollTop: lt,
          viewport: R
        }))
      ),
      Y
    ), O(
      x(
        rt(
          V(d),
          o,
          V(F, Fr),
          V(L, he),
          V(k, he),
          V(nt),
          V(y),
          V(dt),
          V(ft),
          V(St)
        ),
        A(([, , , , , , , R]) => !R),
        E(
          ([
            R,
            [D, Q],
            lt,
            tt,
            Ft,
            Jt,
            Ut,
            ,
            de,
            Ot
          ]) => {
            const { column: Lt, row: Qt } = lt, { height: fe, width: He } = tt, { width: nn } = Ft;
            if (Ut === 0 && (R === 0 || nn === 0))
              return yn;
            if (He === 0) {
              const cn = Ke(Ot, R), co = cn + Math.max(Ut - 1, 0);
              return kr(Hn(cn, co, Jt));
            }
            const me = so(nn, He, Lt);
            let Kt, Wt;
            de ? D === 0 && Q === 0 && Ut > 0 ? (Kt = 0, Wt = Ut - 1) : (Kt = me * Ce((D + Qt) / (fe + Qt)), Wt = me * Rn((Q + Qt) / (fe + Qt)) - 1, Wt = Oe(R - 1, ee(Wt, me - 1)), Kt = Oe(Wt, ee(0, Kt))) : (Kt = 0, Wt = -1);
            const on = Hn(Kt, Wt, Jt), { bottom: rn, top: sn } = En(Ft, lt, tt, on), ln = Rn(R / me), lo = ln * fe + (ln - 1) * Qt - rn;
            return { bottom: rn, itemHeight: fe, items: on, itemWidth: He, offsetBottom: lo, offsetTop: sn, top: sn };
          }
        )
      ),
      B
    ), O(
      x(
        nt,
        A((R) => R !== null),
        E((R) => R.length)
      ),
      d
    ), O(
      x(
        rt(k, L, B, F),
        A(([R, D, { items: Q }]) => Q.length > 0 && D.height !== 0 && R.height !== 0),
        E(([R, D, { items: Q }, lt]) => {
          const { bottom: tt, top: Ft } = En(R, lt, D, Q);
          return [Ft, tt];
        }),
        Z(se)
      ),
      e
    );
    const xt = C(false);
    O(
      x(
        a,
        N(xt),
        E(([R, D]) => D || R !== 0)
      ),
      xt
    );
    const Xt = ht(
      x(
        rt(B, d),
        A(([{ items: R }]) => R.length > 0),
        N(xt),
        A(([[R, D], Q]) => {
          const tt = R.items[R.items.length - 1].index === D - 1;
          return (Q || R.bottom > 0 && R.itemHeight > 0 && R.offsetBottom === 0 && R.items.length === D) && tt;
        }),
        E(([[, R]]) => R - 1),
        Z()
      )
    ), Mt = ht(
      x(
        V(B),
        A(({ items: R }) => R.length > 0 && R[0].index === 0),
        Rt(0),
        Z()
      )
    ), yt = ht(
      x(
        V(B),
        N(dt),
        A(([{ items: R }, D]) => R.length > 0 && !D),
        E(([{ items: R }]) => ({
          endIndex: R[R.length - 1].index,
          startIndex: R[0].index
        })),
        Z(Mn),
        kt(0)
      )
    );
    O(yt, I.scrollSeekRangeChanged), O(
      x(
        z,
        N(k, L, d, F),
        E(([R, D, Q, lt, tt]) => {
          const Ft = Dn(R), { align: Jt, behavior: Ut, offset: de } = Ft;
          let Ot = Ft.index;
          Ot === "LAST" && (Ot = lt - 1), Ot = ee(0, Ot, Oe(lt - 1, Ot));
          let Lt = Me(D, tt, Q, Ot);
          return Jt === "end" ? Lt = bn(Lt - D.height + Q.height) : Jt === "center" && (Lt = bn(Lt - D.height / 2 + Q.height / 2)), de && (Lt += de), { behavior: Ut, top: Lt };
        })
      ),
      c
    );
    const Bt = ct(
      x(
        B,
        E((R) => R.offsetBottom + R.bottom)
      ),
      0
    );
    return O(
      x(
        b,
        E((R) => ({ height: R.visibleHeight, width: R.visibleWidth }))
      ),
      k
    ), {
      customScrollParent: h,
      // input
      data: nt,
      deviation: J,
      footerHeight: r,
      gap: F,
      headerHeight: s,
      increaseViewportBy: t,
      initialItemCount: y,
      itemDimensions: L,
      overscan: n,
      restoreStateFrom: it,
      scrollBy: i,
      scrollContainerState: l,
      scrollHeight: _,
      scrollTo: c,
      scrollToIndex: z,
      scrollTop: a,
      smoothScrollTargetReached: m,
      totalCount: d,
      useWindowScroll: p,
      viewportDimensions: k,
      windowScrollContainerState: u,
      windowScrollTo: T,
      windowViewportRect: b,
      ...I,
      // output
      gridState: B,
      horizontalDirection: At,
      initialTopMostItemIndex: St,
      totalListHeight: Bt,
      ...g,
      endReached: Xt,
      propsReady: v,
      rangeChanged: yt,
      startReached: Mt,
      stateChanged: Y,
      stateRestoreInProgress: dt,
      ...f
    };
  },
  X(je, at, ae, Yn, Pt, qe, Vt)
);
function so(t, e, n) {
  return ee(1, Ce((t + n) / (Ce(e) + n)));
}
function En(t, e, n, o) {
  const { height: r } = n;
  if (r === void 0 || o.length === 0)
    return { bottom: 0, top: 0 };
  const s = Me(t, e, n, o[0].index);
  return { bottom: Me(t, e, n, o[o.length - 1].index) + r, top: s };
}
function Me(t, e, n, o) {
  const r = so(t.width, n.width, e.column), s = Ce(o / r), i = s * n.height + ee(0, s - 1) * e.row;
  return i > 0 ? i + e.row : i;
}
var Lr = U(() => {
  const t = C((S) => `Item ${S}`), e = C({}), n = C(null), o = C("virtuoso-grid-item"), r = C("virtuoso-grid-list"), s = C(Xe), i = C("div"), l = C(Yt), c = (S, g = null) => ct(
    x(
      e,
      E((I) => I[S]),
      Z()
    ),
    g
  ), a = C(false), m = C(false);
  return O(V(m), a), {
    components: e,
    computeItemKey: s,
    context: n,
    FooterComponent: c("Footer"),
    HeaderComponent: c("Header"),
    headerFooterTag: i,
    itemClassName: o,
    ItemComponent: c("Item", "div"),
    itemContent: t,
    listClassName: r,
    ListComponent: c("List", "div"),
    readyStateChanged: a,
    reportReadyState: m,
    ScrollerComponent: c("Scroller", "div"),
    scrollerRef: l,
    ScrollSeekPlaceholder: c("ScrollSeekPlaceholder", "div")
  };
});
var zr = U(
  ([t, e]) => ({ ...t, ...e }),
  X(Or, Lr)
);
var Vr = import_react.default.memo(function() {
  const e = et("gridState"), n = et("listClassName"), o = et("itemClassName"), r = et("itemContent"), s = et("computeItemKey"), i = et("isSeeking"), l = It("scrollHeight"), c = et("ItemComponent"), a = et("ListComponent"), m = et("ScrollSeekPlaceholder"), S = et("context"), g = It("itemDimensions"), I = It("gap"), w = et("log"), v = et("stateRestoreInProgress"), h = It("reportReadyState"), p = Ht(
    import_react.default.useMemo(
      () => (u) => {
        const T = u.parentElement.parentElement.scrollHeight;
        l(T);
        const b = u.firstChild;
        if (b) {
          const { height: f, width: d } = b.getBoundingClientRect();
          g({ height: f, width: d });
        }
        I({
          column: Bn("column-gap", getComputedStyle(u).columnGap, w),
          row: Bn("row-gap", getComputedStyle(u).rowGap, w)
        });
      },
      [l, g, I, w]
    ),
    true,
    false
  );
  return Qn(() => {
    e.itemHeight > 0 && e.itemWidth > 0 && h(true);
  }, [e]), v ? null : (0, import_jsx_runtime.jsx)(
    a,
    {
      className: n,
      ref: p,
      ...q(a, S),
      "data-testid": "virtuoso-item-list",
      style: { paddingBottom: e.offsetBottom, paddingTop: e.offsetTop },
      children: e.items.map((u) => {
        const T = s(u.index, u.data, S);
        return i ? (0, import_jsx_runtime.jsx)(
          m,
          {
            ...q(m, S),
            height: e.itemHeight,
            index: u.index,
            width: e.itemWidth
          },
          T
        ) : (0, import_react.createElement)(
          c,
          {
            ...q(c, S),
            className: o,
            "data-index": u.index,
            key: T
          },
          r(u.index, u.data, S)
        );
      })
    }
  );
});
var Pr = import_react.default.memo(function() {
  const e = et("HeaderComponent"), n = It("headerHeight"), o = et("headerFooterTag"), r = Ht(
    import_react.default.useMemo(
      () => (i) => {
        n(vt(i, "height"));
      },
      [n]
    ),
    true,
    false
  ), s = et("context");
  return e ? (0, import_jsx_runtime.jsx)(o, { ref: r, children: (0, import_jsx_runtime.jsx)(e, { ...q(e, s) }) }) : null;
});
var Ar = import_react.default.memo(function() {
  const e = et("FooterComponent"), n = It("footerHeight"), o = et("headerFooterTag"), r = Ht(
    import_react.default.useMemo(
      () => (i) => {
        n(vt(i, "height"));
      },
      [n]
    ),
    true,
    false
  ), s = et("context");
  return e ? (0, import_jsx_runtime.jsx)(o, { ref: r, children: (0, import_jsx_runtime.jsx)(e, { ...q(e, s) }) }) : null;
});
var Mr = ({ children: t }) => {
  const e = import_react.default.useContext(Jn), n = It("itemDimensions"), o = It("viewportDimensions"), r = Ht(
    import_react.default.useMemo(
      () => (s) => {
        o(s.getBoundingClientRect());
      },
      [o]
    ),
    true,
    false
  );
  return import_react.default.useEffect(() => {
    e && (o({ height: e.viewportHeight, width: e.viewportWidth }), n({ height: e.itemHeight, width: e.itemWidth }));
  }, [e, o, n]), (0, import_jsx_runtime.jsx)("div", { ref: r, style: Zt(false), children: t });
};
var Wr = ({ children: t }) => {
  const e = import_react.default.useContext(Jn), n = It("windowViewportRect"), o = It("itemDimensions"), r = et("customScrollParent"), s = Ne(n, r, false);
  return import_react.default.useEffect(() => {
    e && (o({ height: e.itemHeight, width: e.itemWidth }), n({ offsetTop: 0, visibleHeight: e.viewportHeight, visibleWidth: e.viewportWidth }));
  }, [e, n, o]), (0, import_jsx_runtime.jsx)("div", { ref: s, style: Zt(false), children: t });
};
var Gr = import_react.default.memo(function({ ...e }) {
  const n = et("useWindowScroll"), o = et("customScrollParent"), r = o || n ? Dr : Nr, s = o || n ? Wr : Mr, i = et("context");
  return (0, import_jsx_runtime.jsx)(r, { ...e, ...q(r, i), children: (0, import_jsx_runtime.jsxs)(s, { children: [
    (0, import_jsx_runtime.jsx)(Pr, {}),
    (0, import_jsx_runtime.jsx)(Vr, {}),
    (0, import_jsx_runtime.jsx)(Ar, {})
  ] }) });
});
var {
  Component: _r,
  useEmitter: io,
  useEmitterValue: et,
  usePublisher: It
} = Ye(
  zr,
  {
    optional: {
      context: "context",
      totalCount: "totalCount",
      overscan: "overscan",
      itemContent: "itemContent",
      components: "components",
      computeItemKey: "computeItemKey",
      data: "data",
      initialItemCount: "initialItemCount",
      scrollSeekConfiguration: "scrollSeekConfiguration",
      headerFooterTag: "headerFooterTag",
      listClassName: "listClassName",
      itemClassName: "itemClassName",
      useWindowScroll: "useWindowScroll",
      customScrollParent: "customScrollParent",
      scrollerRef: "scrollerRef",
      logLevel: "logLevel",
      restoreStateFrom: "restoreStateFrom",
      initialTopMostItemIndex: "initialTopMostItemIndex",
      increaseViewportBy: "increaseViewportBy"
    },
    methods: {
      scrollTo: "scrollTo",
      scrollBy: "scrollBy",
      scrollToIndex: "scrollToIndex"
    },
    events: {
      isScrolling: "isScrolling",
      endReached: "endReached",
      startReached: "startReached",
      rangeChanged: "rangeChanged",
      atBottomStateChange: "atBottomStateChange",
      atTopStateChange: "atTopStateChange",
      stateChanged: "stateChanged",
      readyStateChanged: "readyStateChanged"
    }
  },
  Gr
);
var Nr = Je({ useEmitter: io, useEmitterValue: et, usePublisher: It });
var Dr = Qe({ useEmitter: io, useEmitterValue: et, usePublisher: It });
function Bn(t, e, n) {
  return e !== "normal" && !(e != null && e.endsWith("px")) && n(`${t} was not resolved to pixel value correctly`, e, mt.WARN), e === "normal" ? 0 : parseInt(e != null ? e : "0", 10);
}
var Jr = _r;
export {
  Xr as GroupedTableVirtuoso,
  Yr as GroupedVirtuoso,
  mt as LogLevel,
  Zr as TableVirtuoso,
  qr as Virtuoso,
  Jr as VirtuosoGrid,
  Jn as VirtuosoGridMockContext,
  be as VirtuosoMockContext
};
//# sourceMappingURL=react-virtuoso.js.map
