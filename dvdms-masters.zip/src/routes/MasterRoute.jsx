import React from 'react'
import { Route, Routes, useParams } from 'react-router-dom'
import MenuPage from '../pages/MenuPage'
import NotFoundPage from '../pages/NotFoundPage'
import RateContract from '../component/masters/assam/services/RateContract'
import AssamPrivateRoute from './AssamPrivateRoute'
import JharkhandPrivateRoute from './JharkhandPrivateRoute'
import RateContractJH from '../component/masters/jharkhand/services/RateContract'
import RateContractAddForm from '../component/masters/jharkhand/services/RateContract/RateContractAdd'

const MasterRoute = () => {
  const { stateCode } = useParams();
  return (
    <Routes>

      {/* ASSAM */}
      {stateCode === "AS" &&
        <Route element={<AssamPrivateRoute />}>
          <Route path="/rate-contract" element={<RateContract />} />
        </Route>
      }

      {/* JHARKHAND */}
      {stateCode === "JH" &&
        <Route element={<JharkhandPrivateRoute />}>
          <Route path="/rate-contract" element={<RateContractJH />} />
          <Route path="/rate-contract/add" element={<RateContractAddForm />} />
        </Route>
      }

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  )
}

export default MasterRoute
