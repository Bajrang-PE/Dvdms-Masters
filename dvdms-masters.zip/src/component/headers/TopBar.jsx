import React from 'react'
import { FaIdCard, FaHospitalSymbol, FaCalendarCheck, FaEnvelope, FaMapMarkerAlt } from "react-icons/fa";
import { Link } from 'react-router-dom';

const TopBar = ({title,subtitle}) => {
    return (
        <header className="bg-[#34211973] shadow-md border-b border-gray-200">
            <div className="mx-auto flex flex-col md:flex-row justify-between items-center px-3 py-2 space-y-3 md:space-y-0">
                {/* Logo and text */}
                <div className="flex items-center space-x-3">
                    <img
                        src="/logo.png"
                        alt="CGHS Logo"
                        className="h-14 animate-spin-slow bg-white backdrop-blur-sm p-1 rounded-lg border border-white/10 flex-shrink-0"
                    />
                    <div className="leading-tight overflow-hidden">
                        <h5 className="text-[#0081ad] font-bold text-lg relative inline-block">
                            <span className="animate-color-flow">{title}</span>
                        </h5>
                        <p className="text-sm text-green-700 font-bold toplinebg">{subtitle}</p>
                    </div>
                </div>

                {/* Icon actions */}
                <div className="flex flex-col sm:flex-row items-center text-sm gap-4">
                    <div className="flex flex-col items-center text-center">
                        {/* location */}
                        <FaMapMarkerAlt size={20} color='#1e1f90' />
                        <span className="mt-1">AMSCL, Guwahati, Govt. of Assam</span>
                    </div>
                    <div className="flex flex-col items-center text-center sm:border-l sm:px-4">
                        {/* mail */}
                        <FaEnvelope size={20} color='#1e1f90' />
                        <Link to="mailto:mis.nhm-as@gov.in" className="text-decoration-none text-reset">
                            <span className="mt-1">mail</span>
                            mis.nhm-as@gov.in</Link>
                    </div>
                </div>
            </div>
        </header>
    )
}

export default TopBar
